--修改xbn_bank
alter table xbn_bank add column holderType TINYINT(1) NOT NULL DEFAULT 0  COMMENT '持卡人类型0--个人，1--企业';
alter table xbn_bank add column id_no varchar(17)  COMMENT '持卡人身份证号';
alter table xbn_bank add column mobile varchar(11)  COMMENT '持卡人手机号码';
alter table xbn_bank add column living_province varchar(50)  COMMENT '持卡人居住地所在省/市/自治区';
alter table xbn_bank add column living_city varchar(50)  COMMENT '持卡人居住地所在市/区域';
alter table xbn_bank add column living_address varchar(50)  COMMENT '持卡人居住地所在地址';
alter table xbn_bank add column account_province varchar(50)  COMMENT '开户行所在省';
alter table xbn_bank add column account_city varchar(50)  COMMENT '开户行所在市';
alter table xbn_bank add column create_time datetime  COMMENT '记录创建时间';
ALTER TABLE xbn_bank ADD INDEX `full_index` (`user_name`,`banks`,`add_time`,`status`) USING BTREE COMMENT '用户名，银行名称和创建时间,状态索引';

--提现记录表添加索引
ALTER TABLE xbn_withdraw_deposit ADD INDEX `full_index` (`user_name`,`card_no`,`status`,`apply_time`,`process_time`) USING BTREE COMMENT '用户名，

银行账户，提现状态，申请时间，处理时间索引';

--汇率管理添加索引
ALTER TABLE xbn_rate ADD INDEX `full_index` (`type`,`status`,`add_time`) USING BTREE COMMENT '货币类型，汇率状态，添加时间索引';

--收支流水管理表修改字段长度
alter table xbn_account_detail modify column in_out varchar(1) ;

--收支流水管理添加索引
ALTER TABLE xbn_account_detail ADD INDEX `full_index` (`user_name`,`account_name`,`type`,`source`,`add_time`,`in_out`) USING BTREE COMMENT '收支流

水查询索引';

--收支流水表添加分区
alter table xbn_account_detail drop PRIMARY KEY;

ALTER TABLE xbn_account_detail PARTITION BY RANGE(YEAR(add_time)) (    
    PARTITION 2014 VALUES LESS THAN (2015),  
    PARTITION 2015 VALUES LESS THAN (2016)
);

alter table xbn_account_detail add PRIMARY KEY(acc_detail_id,add_time);

--账单管理添加索引
ALTER TABLE xbn_bill ADD INDEX `full_index` (`user_name`,`account_name`,`status`,`settle_time`) USING BTREE COMMENT '账单管理查询索引';

--我购买的服务
CREATE TABLE `finance_service_history` (
`id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' ,
`order_id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci  NOT NULL COMMENT '订单号' ,
`user_id`  int(11)  NOT NULL COMMENT '所属小笨鸟用户id' ,
`user_name`  varchar(100)  NOT NULL COMMENT '所属小笨鸟用户名' ,
`create_time`  datetime NOT NULL COMMENT '创建时间' ,
`update_time`  datetime NOT NULL COMMENT '更新时间' ,
`create_by` varchar(50) NOT NULL COMMENT '创建人id',
`update_by` varchar(50) NOT NULL COMMENT '最后更新人id',
`field_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段1',
`field_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段2',
`field_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段3',
`field_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段4',
`field_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段5',
INDEX `full_index` (`order_id`,`user_name`) USING BTREE COMMENT '用户id索引',
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
COMMENT='我购买的服务'
ROW_FORMAT=COMPACT;

--销售产品表
CREATE TABLE `finance_product` (
`id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' ,
`product_name`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '产品名称' ,
`product_status`  TINYINT(1) NOT NULL DEFAULT 1 COMMENT '产品状态1--可售，0--不可售' ,
`product_price` decimal(10,2) NOT NULL COMMENT '产品价格',
`product_unit` varchar(20) NOT NULL COMMENT '销售单位',
`product_type` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '销售类型0--支持多个购买，1--不支持多个购买',
`is_recommended` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否推荐产品0--不是，1--是',
`picture_id` varchar(50) NOT NULL COMMENT '展示图片id',
`product_introduction` varchar(10000) COMMENT '产品介绍',
`create_time`  datetime NOT NULL COMMENT '创建时间' ,
`update_time`  datetime NOT NULL COMMENT '更新时间' ,
`create_by` varchar(50) NOT NULL COMMENT '创建人id',
`update_by` varchar(50) NOT NULL COMMENT '最后更新人id',
`field_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段1',
`field_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段2',
`field_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段3',
`field_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段4',
`field_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段5',
INDEX `is_recommended_index` (`is_recommended`) USING BTREE COMMENT '是否推荐产品索引',
INDEX `name_time_index` (`product_name`,`create_time`) USING BTREE COMMENT '产品名称和时间索引',
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
COMMENT='销售产品表'
ROW_FORMAT=COMPACT;

--订单详情表
CREATE TABLE `finance_order` (
`id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' ,
`user_id`  int(11)  NOT NULL COMMENT '所属小笨鸟用户id' ,
`cart_ids`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '购物车id列表',
`order_amount` int(11) NOT NULL COMMENT '订单金额',
`pay_status` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '付款状态0--未付款，1--已付款',
`pay_amount` int(11) COMMENT '付款金额',
`pay_time`  datetime NULL DEFAULT NULL COMMENT '付款时间' ,
`pay_type` varchar(255) COMMENT '付款方式',
`tran_id` varchar(32) COMMENT '交易流水号',
`open_status` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '开通状态0--未开通，1--已开通',
`create_time`  datetime NOT NULL COMMENT '创建时间' ,
`update_time`  datetime NOT NULL COMMENT '更新时间' ,
`open_by` varchar(50)  COMMENT '开通管理员',
`open_remark` varchar(500)  COMMENT '开通备注',
`order_remark` varchar(500)  COMMENT '订单备注',
`field_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段1',
`field_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段2',
`field_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段3',
`field_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段4',
`field_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段5',
INDEX `time_index` (`id`,`create_time`) USING BTREE COMMENT '订单号和时间索引',
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
COMMENT='订单表'
ROW_FORMAT=COMPACT;

--购物车
CREATE TABLE `shopping_cart` (
`id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' ,
`user_id`  int(11) NOT NULL COMMENT '所属小笨鸟用户' ,
`product_id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL  COMMENT '购买产品id',
`promotion_id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '促销活动id',
`price` decimal(10,2) NOT NULL COMMENT '价格',
`product_count` int(11) NOT NULL COMMENT '数量',
`create_time`  datetime NOT NULL COMMENT '创建时间' ,
`update_time`  datetime NOT NULL COMMENT '更新时间' ,
`creat_by` varchar(50) NOT NULL  COMMENT '创建人',
`update_by` varchar(50) NOT NULL  COMMENT '最后更新人',
`field_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段1',
`field_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段2',
`field_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段3',
`field_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段4',
`field_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段5',
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
COMMENT='购物车'
ROW_FORMAT=COMPACT;

--促销活动表
CREATE TABLE `finance_promotion` (
`id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' ,
`promotion_type`  TINYINT(1) NOT NULL DEFAULT 0 NULL COMMENT '促销活动类型0--单品促销，1--组合促销' ,
`promotion_name`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '促销活动名称',
`start_time`  datetime NOT NULL COMMENT '促销活动开始时间' ,
`end_time`  datetime NOT NULL COMMENT '促销活动结束时间' ,
`promotion_status`  TINYINT(1) NOT NULL DEFAULT 0 COMMENT '促销活动状态0--暂停，1--正常' ,
`product_ids` varchar(800) NOT NULL COMMENT '选择产品id列表',
`promotion_type_ids` varchar(800) NOT NULL COMMENT '促销方式id列表',
`create_time`  datetime NOT NULL COMMENT '创建时间' ,
`update_time`  datetime NNOT NULL COMMENT '更新时间' ,
`create_by` varchar(50) NOT NULL COMMENT '创建人id',
`update_by` varchar(50) NOT NULL COMMENT '最后更新人id',
`field_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段1',
`field_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段2',
`field_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段3',
`field_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段4',
`field_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段5',
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
COMMENT='促销活动表'
ROW_FORMAT=COMPACT;

--促销方式表
CREATE TABLE `finance_promotion_type` (
`id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' ,
`discount_type`  TINYINT(2) NOT NULL DEFAULT 0 NULL COMMENT '折扣类型0--单一折扣，1--阶梯折扣，2--买赠活动' ,
`service_type`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '服务类型',
`user_grade`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户等级',
`user_role`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户角色',
`discount_id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '折扣id',
`create_time`  datetime NULL DEFAULT NULL COMMENT '创建时间' ,
`update_time`  datetime NULL DEFAULT NULL COMMENT '更新时间' ,
`create_by` varchar(50) NOT NULL COMMENT '创建人id',
`update_by` varchar(50) NOT NULL COMMENT '最后更新人id',
`field_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段1',
`field_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段2',
`field_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段3',
`field_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段4',
`field_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段5',
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
COMMENT='促销方式表'
ROW_FORMAT=COMPACT;

--单一折扣表
CREATE TABLE `single_discount` (
`id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' ,
`discount_rate`  decimal(2,2) NOT NULL COMMENT '折扣率',
`start_value`  decimal(10,2) NOT NULL COMMENT '折扣开始值',
`end_value`  decimal(10,2) NOT NULL COMMENT '折扣结束值',
`create_time`  datetime NOT NULL COMMENT '创建时间' ,
`update_time`  datetime NOT NULL COMMENT '更新时间' ,
`create_by` varchar(50) NOT NULL COMMENT '创建人id',
`update_by` varchar(50) NOT NULL COMMENT '最后更新人id',
`field_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段1',
`field_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段2',
`field_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段3',
`field_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段4',
`field_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段5',
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
COMMENT='单一折扣表'
ROW_FORMAT=COMPACT;

--阶梯折扣表
CREATE TABLE `ladder_discount` (
`id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' ,
`single_discount_ids` varchar(800) NOT NULL COMMENT '单一折扣的id列表',
`create_time`  datetime NOT NULL COMMENT '创建时间' ,
`update_time`  datetime NOT NULL COMMENT '更新时间' ,
`create_by` varchar(50) NOT NULL COMMENT '创建人id',
`update_by` varchar(50) NOT NULL COMMENT '最后更新人id',
`field_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段1',
`field_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段2',
`field_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段3',
`field_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段4',
`field_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段5',
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
COMMENT='阶梯折扣表'
ROW_FORMAT=COMPACT;

--买赠折扣表
CREATE TABLE `gift_discount` (
`id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' ,
`product_ids` varchar(800) COMMENT '赠品id列表',
`create_time`  datetime NOT NULL COMMENT '创建时间' ,
`update_time`  datetime NOT NULL COMMENT '更新时间' ,
`create_by` varchar(50) NOT NULL COMMENT '创建人id',
`update_by` varchar(50) NOT NULL COMMENT '最后更新人id',
`field_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段1',
`field_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段2',
`field_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段3',
`field_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段4',
`field_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段5',
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
COMMENT='买赠折扣表'
ROW_FORMAT=COMPACT;

--保证金管理表
CREATE TABLE `finance_deposit` (
`id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' ,
`tran_id` varchar(32) COMMENT '交易流水号',
`user_id`  int(11) NULL DEFAULT NULL COMMENT '所属小笨鸟用户' ,
`user_mobile`  varchar(11) COMMENT '所属小笨鸟用户的手机号' ,
`deposit_user_name`  varchar(100) COMMENT '保证金交付人/单位名称' ,
`plan_pay_time`  datetime NOT NULL COMMENT '应付时间' ,
`plan_pay_amount`  decimal(10,2) NOT NULL COMMENT '应付金额',
`actual_pay_time`  datetime NOT NULL COMMENT '实付时间' ,
`actual_pay_amount`  decimal(10,2) NOT NULL COMMENT '实付金额',
`pay_status` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '付款状态0--未付款，1--已付款',
`create_time`  datetime NOT NULL COMMENT '创建时间' ,
`update_time`  datetime NOT NULL COMMENT '更新时间' ,
`opration_by` varchar(50) NOT NULL COMMENT '操作人id',
`create_by` varchar(50) NOT NULL COMMENT '创建人id',
`update_by` varchar(50) NOT NULL COMMENT '最后更新人id',
`field_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段1',
`field_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段2',
`field_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段3',
`field_4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段4',
`field_5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预留字段5',
INDEX `full_search_index` (`user_mobile`,`deposit_user_name`,`pay_status`,`opration_by`,
`plan_pay_time`,`actual_pay_time`) USING BTREE COMMENT '保证金搜索索引',
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
COMMENT='保证金管理表'
ROW_FORMAT=COMPACT;