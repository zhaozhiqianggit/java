/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2015/8/3 16:15:56                            */
/*==============================================================*/


drop index idx_admin_isvalid on xbn_admin;

drop index idx_admin_issuper on xbn_admin;

drop index idx_admin_name on xbn_admin;

drop table if exists xbn_admin;

drop index idx_admin_role_isvalid on xbn_admin_role;

drop index idx_admin_role_name on xbn_admin_role;

drop table if exists xbn_admin_role;

drop index idx_menu_name on xbn_menu;

drop index idx_menu_isvalid on xbn_menu;

drop index idx_menu_type on xbn_menu;

drop index idx_menu_parent_id on xbn_menu;

drop table if exists xbn_menu;

drop index idx_role_isvalid on xbn_role;

drop index idx_role_name on xbn_role;

drop table if exists xbn_role;

drop index idx_role_group_isvalid on xbn_role_group;

drop index idx_role_group_name on xbn_role_group;

drop table if exists xbn_role_group;

drop table if exists xbn_sys_interface;

drop index idx_sys_menu_isvalid on xbn_sys_menu;

drop index idx_sys_menu_type on xbn_sys_menu;

drop index idx_sys_menu_parent_id on xbn_sys_menu;

drop table if exists xbn_sys_menu;

drop index idx_user_level_isvalid on xbn_user_level;

drop index idx_user_level_name on xbn_user_level;

drop table if exists xbn_user_level;

drop index idx_level_detail_isvalid on xbn_user_level_detail;

drop index idx_level_type_id on xbn_user_level_detail;

drop index idx_user_level_id on xbn_user_level_detail;

drop table if exists xbn_user_level_detail;

drop index idx_level_type_isvalid on xbn_user_level_type;

drop index idx_level_type_name on xbn_user_level_type;

drop table if exists xbn_user_level_type;

/*==============================================================*/
/* Table: xbn_admin                                             */
/*==============================================================*/
create table xbn_admin
(
   id                   varchar(32) not null comment '业务主键',
   name                 varchar(32) comment '账户名称',
   password             varchar(32) comment '账户密码',
   is_super             tinyint default 0 comment '是否超级管理员
            （''0'':否 ''1'':是）',
   operator             varchar(32),
   is_valid             tinyint default 1 comment '数据是否有效 （0：否 1：是）',
   role_id              varchar(32) comment '管理员角色ID',
   create_time          datetime comment '数据创建时间',
   update_time          datetime comment '数据更新时间',
   remark               varchar(255) comment '备用字段',
   version              datetime comment '数据版本信息',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

/*==============================================================*/
/* Index: idx_admin_name                                        */
/*==============================================================*/
create index idx_admin_name on xbn_admin
(
   name
);

/*==============================================================*/
/* Index: idx_admin_issuper                                     */
/*==============================================================*/
create index idx_admin_issuper on xbn_admin
(
   is_super
);

/*==============================================================*/
/* Index: idx_admin_isvalid                                     */
/*==============================================================*/
create index idx_admin_isvalid on xbn_admin
(
   is_valid
);


/*==============================================================*/
/* Index: idx_admin_role_id                                     */
/*==============================================================*/
create index idx_admin_role_id on xbn_admin
(
   role_id
);

/*==============================================================*/
/* Table: xbn_admin_role                                        */
/*==============================================================*/
create table xbn_admin_role
(
   id                   varchar(32) not null comment '业务主键',
   role_name            varchar(255) comment '角色名称',
   operator             varchar(32) comment '操作人',
   is_valid             tinyint default 0 comment '数据是否有效  (0 ： 否 1：是)',
   create_time          datetime comment '数据创建时间',
   update_time          datetime comment '数据更新时间',
   remark               varchar(255) comment '备用字段',
   version              datetime comment '数据版本信息',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_admin_role comment '管理员角色';

/*==============================================================*/
/* Index: idx_admin_role_name                                   */
/*==============================================================*/
create index idx_admin_role_name on xbn_admin_role
(
   role_name
);

/*==============================================================*/
/* Index: idx_admin_role_isvalid                                */
/*==============================================================*/
create index idx_admin_role_isvalid on xbn_admin_role
(
   is_valid
);

/*==============================================================*/
/* Table: xbn_menu                                              */
/*==============================================================*/
create table xbn_menu
(
   id                   int not null auto_increment comment '业务主键',
   parent_id            varchar(32) comment '父级菜单ID',
   menu_name            varchar(255) comment '菜单名称',
   level                int comment '菜单级别',
   code                 varchar(255) comment '编码CODE',
   url                  varchar(255) comment '菜单链接',
   menu_type            char(1) comment '菜单类型 :  ‘1’ ：菜单  ''2'': Tab ''3'': button',
   sort                 int comment '菜单排序',
   operator             varchar(255),
   is_valid             tinyint default 1 comment '数据是否有效 （0：否 1：是） ',
   create_time          datetime comment '数据创建时间',
   update_time          datetime comment '数据更新时间',
   remark               varchar(255) comment '备用字段',
   version              datetime comment '数据版本信息',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_menu comment '系统菜单（会员）';

/*==============================================================*/
/* Index: idx_menu_parent_id                                    */
/*==============================================================*/
create index idx_menu_parent_id on xbn_menu
(
   parent_id
);

/*==============================================================*/
/* Index: idx_menu_type                                         */
/*==============================================================*/
create index idx_menu_type on xbn_menu
(
   menu_type
);

/*==============================================================*/
/* Index: idx_menu_isvalid                                      */
/*==============================================================*/
create index idx_menu_isvalid on xbn_menu
(
   is_valid
);

/*==============================================================*/
/* Index: idx_menu_name                                         */
/*==============================================================*/
create index idx_menu_name on xbn_menu
(
   menu_name
);

/*==============================================================*/
/* Table: xbn_role                                              */
/*==============================================================*/
create table xbn_role
(
   id                   varchar(32) not null comment '业务主键',
   role_name            varchar(255) comment '角色名称',
   operator             varchar(32) comment '操作人',
   is_valid             tinyint default 1 comment '数据是否有效 （0：否 1：是）',
   create_time          datetime comment '数据创建时间',
   update_time          datetime comment '数据更新时间',
   remark               varchar(255) comment '备用字段',
   version              datetime comment '数据版本信息',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_role comment '会员角色';

/*==============================================================*/
/* Index: idx_role_name                                         */
/*==============================================================*/
create index idx_role_name on xbn_role
(
   role_name
);

/*==============================================================*/
/* Index: idx_role_isvalid                                      */
/*==============================================================*/
create index idx_role_isvalid on xbn_role
(
   is_valid
);

/*==============================================================*/
/* Table: xbn_role_group                                        */
/*==============================================================*/
create table xbn_role_group
(
   id                   varchar(32) not null comment '业务主键',
   group_name           varchar(255) comment '角色名称',
   operator             varchar(32) comment '操作人',
   is_valid             tinyint default 1 comment '数据是否有效 （0：否 1：是）',
   create_time          datetime comment '数据创建时间',
   update_time          datetime comment '数据更新时间',
   remark               varchar(255) comment '备用字段',
   version              datetime comment '数据版本信息',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_role_group comment '会员角色组';

/*==============================================================*/
/* Index: idx_role_group_name                                   */
/*==============================================================*/
create index idx_role_group_name on xbn_role_group
(
   group_name
);

/*==============================================================*/
/* Index: idx_role_group_isvalid                                */
/*==============================================================*/
create index idx_role_group_isvalid on xbn_role_group
(
   is_valid
);

/*==============================================================*/
/* Table: xbn_sys_interface                                     */
/*==============================================================*/
create table xbn_sys_interface
(
   id                   integer not null auto_increment,
   name                 varchar(255) comment '接口名称',
   url                  varchar(255),
   description          varchar(1000) comment '接口描述',
   create_time          datetime default current_timestamp comment '数据创建时间',
   update_time          datetime default current_timestamp comment '数据更新时间',
   remark               varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '数据是否有效',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_sys_interface comment '系统接口信息表';

/*==============================================================*/
/* Table: xbn_sys_menu                                          */
/*==============================================================*/
create table xbn_sys_menu
(
   id                   int not null auto_increment comment '业务主键',
   parent_id            varchar(32) comment '父菜单ID',
   menu_name            varchar(255) comment '菜单名称',
   level                int comment '菜单级别',
   code                 varchar(255) comment '编码',
   url                  varchar(255) comment 'URL地址',
   menu_type            char(1) comment '菜单类型 :  ‘1’ ：菜单  ''2'': Tab ''3'': button',
   operator             varchar(255) comment '操作人',
   sort                 int comment '菜单排序',
   is_valid             tinyint default 1 comment '数据是否有效 （0：否 1：是）',
   create_time          datetime comment '数据创建时间',
   update_time          datetime comment '数据更新时间',
   remark               varchar(255) comment '备用字段',
   version              datetime comment '数据版本信息',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_sys_menu comment '系统菜单';

/*==============================================================*/
/* Index: idx_sys_menu_parent_id                                */
/*==============================================================*/
create index idx_sys_menu_parent_id on xbn_sys_menu
(
   parent_id
);

/*==============================================================*/
/* Index: idx_sys_menu_type                                     */
/*==============================================================*/
create index idx_sys_menu_type on xbn_sys_menu
(
   menu_type
);

/*==============================================================*/
/* Index: idx_sys_menu_isvalid                                  */
/*==============================================================*/
create index idx_sys_menu_isvalid on xbn_sys_menu
(
   is_valid
);

/*==============================================================*/
/* Table: xbn_user_level                                        */
/*==============================================================*/
create table xbn_user_level
(
   id                   varchar(32) not null,
   level_name           varchar(255) comment '等级名称',
   is_valid             tinyint default 1 comment '数据是否有效（0：否 1：是）',
   operator             varchar(32) comment '操作人',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               varchar(255) comment '备用字段',
   version              datetime comment '数据版本信息',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_user_level comment '会员等级';

/*==============================================================*/
/* Index: idx_user_level_name                                   */
/*==============================================================*/
create index idx_user_level_name on xbn_user_level
(
   level_name
);

/*==============================================================*/
/* Index: idx_user_level_isvalid                                */
/*==============================================================*/
create index idx_user_level_isvalid on xbn_user_level
(
   is_valid
);

/*==============================================================*/
/* Table: xbn_user_level_detail                                 */
/*==============================================================*/
create table xbn_user_level_detail
(
   id                   varchar(32) not null,
   val                  double(10,2) comment '取值',
   level_id             varchar(32) comment '会员等级',
   type_id              int comment '等级类型',
   operator             varchar(32) comment '操作人',
   is_valid             tinyint default 1 comment '数据是否有效 （0：否 1：是）',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               varchar(255) comment '备用字段',
   version              datetime comment '数据版本信息',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_user_level_detail comment '会员等级详情';

/*==============================================================*/
/* Index: idx_user_level_id                                     */
/*==============================================================*/
create index idx_user_level_id on xbn_user_level_detail
(
   level_id
);

/*==============================================================*/
/* Index: idx_level_type_id                                     */
/*==============================================================*/
create index idx_level_type_id on xbn_user_level_detail
(
   type_id
);

/*==============================================================*/
/* Index: idx_level_detail_isvalid                              */
/*==============================================================*/
create index idx_level_detail_isvalid on xbn_user_level_detail
(
   is_valid
);

/*==============================================================*/
/* Table: xbn_user_level_type                                   */
/*==============================================================*/
create table xbn_user_level_type
(
   id                   int not null auto_increment,
   type_name            varchar(255) comment '类型名称',
   is_valid             tinyint default 0 comment '数据是否有效（0：无效 1：有效）',
   operator             varchar(32) comment '操作人',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               varchar(255) comment '备用字段',
   version              datetime comment '数据版本信息',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_user_level_type comment '会员等级类型';

/*==============================================================*/
/* Index: idx_level_type_name                                   */
/*==============================================================*/
create index idx_level_type_name on xbn_user_level_type
(
   type_name
);

/*==============================================================*/
/* Index: idx_level_type_isvalid                                */
/*==============================================================*/
create index idx_level_type_isvalid on xbn_user_level_type
(
   is_valid
);

