/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2015/7/22 9:52:25                            */
/*==============================================================*/


drop table if exists xbn_announcement;

drop table if exists xbn_audit_event_log;

drop table if exists xbn_base_bank;

drop table if exists xbn_base_site;

drop index user_company_name_index on xbn_company_info;

drop index company_user_id_index on xbn_company_info;

drop table if exists xbn_company_info;

drop index user_bank_account_user_id_index on xbn_corp_bank_account;

drop index user_bank_account_province_index on xbn_corp_bank_account;

drop index user_bank_account_name_index on xbn_corp_bank_account;

drop index user_bank_account_company_id_index on xbn_corp_bank_account;

drop index user_bank_account_city_index on xbn_corp_bank_account;

drop index user_bank_account_branch_code_index on xbn_corp_bank_account;

drop table if exists xbn_corp_bank_account;

drop index user_qualification_user_id_index on xbn_corp_brand_qualification;

drop index user_qualification_en_name on xbn_corp_brand_qualification;

drop index user_qualification_company_id_index on xbn_corp_brand_qualification;

drop index user_qualification_cn_name on xbn_corp_brand_qualification;

drop index user_qualification_business_model_index on xbn_corp_brand_qualification;

drop index user_qualification_brand_type_index on xbn_corp_brand_qualification;

drop index user_qualification_audit_status on xbn_corp_brand_qualification;

drop table if exists xbn_corp_brand_qualification;

drop index business_category_user_id_index on xbn_corp_business_category;

drop index business_category_second_name_index on xbn_corp_business_category;

drop index business_category_second_code_index on xbn_corp_business_category;

drop index business_category_qualification_id_index on xbn_corp_business_category;

drop index business_category_first_name_index on xbn_corp_business_category;

drop index business_category_first_code_index on xbn_corp_business_category;

drop index business_category_company_id_index on xbn_corp_business_category;

drop table if exists xbn_corp_business_category;

drop index user_additional_qualification_user_id_index on xbn_corp_extra_qualification;

drop index user_additional_qualification_name_index on xbn_corp_extra_qualification;

drop index user_additional_qualification_company_id_index on xbn_corp_extra_qualification;

drop table if exists xbn_corp_extra_qualification;

drop index email_auth_user_id_index on xbn_email_auth_info;

drop index email_auth_is_actived_index on xbn_email_auth_info;

drop index email_auth_index on xbn_email_auth_info;

drop index email_auth_code_index on xbn_email_auth_info;

drop table if exists xbn_email_auth_info;

drop index sys_parent_area_name_index on xbn_sys_area;

drop index sys_parent_area_code_index on xbn_sys_area;

drop index sys_area_name_index on xbn_sys_area;

drop index sys_area_level_index on xbn_sys_area;

drop index sys_area_code_index on xbn_sys_area;

drop table if exists xbn_sys_area;

drop index sys_extend_value_index on xbn_sys_extend;

drop index sys_extend_type_index on xbn_sys_extend;

drop index sys_extend_name_index on xbn_sys_extend;

drop index sys_extend_field_9_index on xbn_sys_extend;

drop index sys_extend_field_8_index on xbn_sys_extend;

drop index sys_extend_field_7_index on xbn_sys_extend;

drop index sys_extend_field_6_index on xbn_sys_extend;

drop index sys_extend_field_5_index on xbn_sys_extend;

drop index sys_extend_field_4_index on xbn_sys_extend;

drop index sys_extend_field_3_index on xbn_sys_extend;

drop index sys_extend_field_2_index on xbn_sys_extend;

drop index sys_extend_field_1_index on xbn_sys_extend;

drop index sys_extend_field_10_index on xbn_sys_extend;

drop index sys_extend_data_type_index on xbn_sys_extend;

drop table if exists xbn_sys_extend;

drop index user_mobile_index on xbn_user;

drop index user_is_bind_mobile on xbn_user;

drop index user_is_active_email on xbn_user;

drop index user_email_index on xbn_user;

drop table if exists xbn_user;

drop table if exists xbn_user_login_log;

drop table if exists xbn_base_logistics;

drop table if exists xbn_category;

drop table if exists xbn_category_maping;

drop index idx_category_seller_mapping_platform_code on xbn_category_seller_mapping;

drop index idx_category_seller_mapping_site on xbn_category_seller_mapping;

drop index idx_category_seller_mapping_shipping_type on xbn_category_seller_mapping;

drop index idx_category_seller_mapping_seller on xbn_category_seller_mapping;

drop index idx_category_seller_mapping_category_id on xbn_category_seller_mapping;

drop table if exists xbn_category_seller_mapping;

drop table if exists xbn_keyword;

drop index business_category_user_id_index on xbn_qualification_site;

drop index business_category_qualification_id_index on xbn_qualification_site;

drop table if exists xbn_qualification_site;

drop table if exists xbn_sms_send_log;

/*==============================================================*/
/* Table: xbn_announcement                                      */
/*==============================================================*/
create table xbn_announcement
(
   id                   national varchar(32) not null comment '主键',
   content              national text comment '正文',
   author               national varchar(255) comment '创建人',
   user_id              national varchar(32) comment '用户ID',
   create_time          national datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_announcement comment '系统公告';

/*==============================================================*/
/* Table: xbn_audit_event_log                                   */
/*==============================================================*/
create table xbn_audit_event_log
(
   id                   varchar(32) not null comment '主键',
   ref_id               varchar(32) comment '关联ID',
   event_type           varchar(10) comment '事件类型',
   event_reason         varchar(2000) comment '事件原因',
   operate_time         datetime comment '操作时间',
   operater             varchar(255) comment '操作人',
   service_type         varchar(10) comment '业务类型',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_audit_event_log comment '系统审核日志';

/*==============================================================*/
/* Table: xbn_base_bank                                         */
/*==============================================================*/
create table xbn_base_bank
(
   id                   varchar(32) not null comment '主键',
   bank_name            varchar(255) comment '网点名称',
   bank_code            varchar(255) comment '银行代码',
   area_code            varchar(255) comment '地区编码',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_base_bank comment '基础银行网点信息';

/*==============================================================*/
/* Table: xbn_base_site                                         */
/*==============================================================*/
create table xbn_base_site
(
   id                   varchar(32) not null comment '主键',
   site_name            varchar(255) comment '站点名称',
   site_code            varchar(255) comment '站点编码',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   platform_code        varchar(255) comment '所属平台',
   country              varchar(32) comment '国家',
   language             varchar(32) comment '语种',
   currency             varchar(32) comment '币种',
   image_max_count      int comment '最大图片数量',
   image_free_count     int comment '免费图片数',
   pack_length_unit     varchar(32) comment '包装长度单位（）',
   pack_weight_unit     varchar(32) comment '包装重量单位',
   weight_max           varchar(32) comment '单品最大重量(0不限制)',
   commodity_describe_type tinyint comment '商品描述类型',
   subscribe_type       tinyint comment '订购要求',
   site_cost            varchar(32) comment '站点费用',
   commissionrate_type  tinyint comment '小笨鸟交易佣金率方式',
   commissionrate       varchar(32) comment '小笨鸟交易佣金率',
   status               tinyint comment '状态（启用、禁用）',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_base_site comment '小笨鸟基础站点信息';

/*==============================================================*/
/* Table: xbn_company_info                                      */
/*==============================================================*/
create table xbn_company_info
(
   id                   national varchar(32) not null comment '主键',
   company_name         national varchar(255) comment '企业名称',
   province             varchar(32) comment '所在省份',
   city                 varchar(32) comment '所在地市',
   county               varchar(32) comment '所在区县',
   address              national varchar(500) comment '企业地址',
   postcode             national varchar(255) comment '邮编',
   legal_represent      national varchar(255) comment '法人代表',
   registered_no        national varchar(255) comment '工商注册号',
   sku_total            int comment '单品SKU总量',
   average_sku_price    varchar(255) comment '单品均价',
   description          varchar(2000) comment '企业简介',
   audit_status         varchar(255) comment '审核状态',
   user_id              national varchar(32) comment '会员ID',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   chk_time             datetime comment '审核时间',
   payable              varchar(32) comment '应付保证金',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

/*==============================================================*/
/* Index: company_user_id_index                                 */
/*==============================================================*/
create index company_user_id_index on xbn_company_info
(
   user_id
);

/*==============================================================*/
/* Index: user_company_name_index                               */
/*==============================================================*/
create index user_company_name_index on xbn_company_info
(
   company_name
);

/*==============================================================*/
/* Table: xbn_corp_bank_account                                 */
/*==============================================================*/
create table xbn_corp_bank_account
(
   id                   national varchar(32) not null comment '主键',
   company_id           national varchar(32) comment '企业ID',
   user_id              national varchar(32) comment '用户ID',
   bank                 national varchar(255) comment '开户银行',
   province             national varchar(255) comment '省份',
   city                 national varchar(255) comment '地市',
   branch               national varchar(255) comment '网点',
   branch_code          national varchar(255) comment '银行网点联行号',
   account_name         national varchar(255) comment '开户名',
   bank_account         national varchar(255) comment '银行帐号',
   audit_status         varchar(255) comment '审核状态',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   licence              varchar(32) comment '银行开户许可证(副本)',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_corp_bank_account comment '银行开户信息';

/*==============================================================*/
/* Index: user_bank_account_branch_code_index                   */
/*==============================================================*/
create index user_bank_account_branch_code_index on xbn_corp_bank_account
(
   branch_code
);

/*==============================================================*/
/* Index: user_bank_account_city_index                          */
/*==============================================================*/
create index user_bank_account_city_index on xbn_corp_bank_account
(
   city
);

/*==============================================================*/
/* Index: user_bank_account_company_id_index                    */
/*==============================================================*/
create index user_bank_account_company_id_index on xbn_corp_bank_account
(
   company_id
);

/*==============================================================*/
/* Index: user_bank_account_name_index                          */
/*==============================================================*/
create index user_bank_account_name_index on xbn_corp_bank_account
(
   bank
);

/*==============================================================*/
/* Index: user_bank_account_province_index                      */
/*==============================================================*/
create index user_bank_account_province_index on xbn_corp_bank_account
(
   province
);

/*==============================================================*/
/* Index: user_bank_account_user_id_index                       */
/*==============================================================*/
create index user_bank_account_user_id_index on xbn_corp_bank_account
(
   user_id
);

/*==============================================================*/
/* Table: xbn_corp_brand_qualification                          */
/*==============================================================*/
create table xbn_corp_brand_qualification
(
   id                   national varchar(32) not null comment '主键',
   company_id           national varchar(32) comment '企业ID',
   user_id              national varchar(32) comment '会员ID',
   cn_name              national varchar(255) comment '品牌中文名称',
   en_name              national varchar(255) comment '品牌英文名称',
   business_model       national varchar(255) comment '经营模式',
   brand_type           national varchar(255) comment '商标类型',
   brand_expire_time    datetime comment '商标有效期',
   audit_status         national varchar(255) comment '审核状态',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   certificate          varchar(32) comment '商标注册证/商标注册申请受理书',
   chktime              datetime comment '审核时间',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_corp_brand_qualification comment '企业品牌资质';

/*==============================================================*/
/* Index: user_qualification_audit_status                       */
/*==============================================================*/
create index user_qualification_audit_status on xbn_corp_brand_qualification
(
   audit_status
);

/*==============================================================*/
/* Index: user_qualification_brand_type_index                   */
/*==============================================================*/
create index user_qualification_brand_type_index on xbn_corp_brand_qualification
(
   brand_type
);

/*==============================================================*/
/* Index: user_qualification_business_model_index               */
/*==============================================================*/
create index user_qualification_business_model_index on xbn_corp_brand_qualification
(
   business_model
);

/*==============================================================*/
/* Index: user_qualification_cn_name                            */
/*==============================================================*/
create index user_qualification_cn_name on xbn_corp_brand_qualification
(
   cn_name
);

/*==============================================================*/
/* Index: user_qualification_company_id_index                   */
/*==============================================================*/
create index user_qualification_company_id_index on xbn_corp_brand_qualification
(
   company_id
);

/*==============================================================*/
/* Index: user_qualification_en_name                            */
/*==============================================================*/
create index user_qualification_en_name on xbn_corp_brand_qualification
(
   en_name
);

/*==============================================================*/
/* Index: user_qualification_user_id_index                      */
/*==============================================================*/
create index user_qualification_user_id_index on xbn_corp_brand_qualification
(
   user_id
);

/*==============================================================*/
/* Table: xbn_corp_business_category                            */
/*==============================================================*/
create table xbn_corp_business_category
(
   id                   national varchar(32) not null comment '主键',
   user_id              national varchar(32) comment '会员ID',
   company_id           national varchar(32) comment '企业ID',
   qualification_id     national varchar(32) comment '资质ID',
   first_category_code  national varchar(255) comment '商品一级类目编码',
   first_category_name  national varchar(255) comment '商品一级类目名称',
   second_category_code national varchar(255) comment '商品二级类目编码',
   second_category_name national varchar(255) comment '商品二级类目名称',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_corp_business_category comment '企业经营类目信息';

/*==============================================================*/
/* Index: business_category_company_id_index                    */
/*==============================================================*/
create index business_category_company_id_index on xbn_corp_business_category
(
   company_id
);

/*==============================================================*/
/* Index: business_category_first_code_index                    */
/*==============================================================*/
create index business_category_first_code_index on xbn_corp_business_category
(
   first_category_code
);

/*==============================================================*/
/* Index: business_category_first_name_index                    */
/*==============================================================*/
create index business_category_first_name_index on xbn_corp_business_category
(
   first_category_name
);

/*==============================================================*/
/* Index: business_category_qualification_id_index              */
/*==============================================================*/
create index business_category_qualification_id_index on xbn_corp_business_category
(
   qualification_id
);

/*==============================================================*/
/* Index: business_category_second_code_index                   */
/*==============================================================*/
create index business_category_second_code_index on xbn_corp_business_category
(
   second_category_code
);

/*==============================================================*/
/* Index: business_category_second_name_index                   */
/*==============================================================*/
create index business_category_second_name_index on xbn_corp_business_category
(
   second_category_name
);

/*==============================================================*/
/* Index: business_category_user_id_index                       */
/*==============================================================*/
create index business_category_user_id_index on xbn_corp_business_category
(
   user_id
);

/*==============================================================*/
/* Table: xbn_corp_extra_qualification                          */
/*==============================================================*/
create table xbn_corp_extra_qualification
(
   id                   national varchar(32) not null comment '主键',
   company_id           national varchar(32) comment '企业ID',
   user_id              national varchar(32) comment '会员ID',
   qualification_name   national varchar(255) comment '资质名称',
   expire_time          datetime comment '有效期',
   audit_status         varchar(255) comment '审核状态',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   chktime              datetime comment '审核时间',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_corp_extra_qualification comment '企业其它资质';

/*==============================================================*/
/* Index: user_additional_qualification_company_id_index        */
/*==============================================================*/
create index user_additional_qualification_company_id_index on xbn_corp_extra_qualification
(
   company_id
);

/*==============================================================*/
/* Index: user_additional_qualification_name_index              */
/*==============================================================*/
create index user_additional_qualification_name_index on xbn_corp_extra_qualification
(
   qualification_name
);

/*==============================================================*/
/* Index: user_additional_qualification_user_id_index           */
/*==============================================================*/
create index user_additional_qualification_user_id_index on xbn_corp_extra_qualification
(
   user_id
);

/*==============================================================*/
/* Table: xbn_email_auth_info                                   */
/*==============================================================*/
create table xbn_email_auth_info
(
   id                   national varchar(32) not null comment '主键',
   user_id              national varchar(32) comment '会员ID',
   auth_code            national varchar(255) comment '激活码',
   email                national varchar(255) comment '验证邮箱',
   expire_time          datetime comment '过期时间',
   is_actived           tinyint(1) comment '是否激活',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_email_auth_info comment '用户邮箱激活信息';

/*==============================================================*/
/* Index: email_auth_code_index                                 */
/*==============================================================*/
create index email_auth_code_index on xbn_email_auth_info
(
   auth_code
);

/*==============================================================*/
/* Index: email_auth_index                                      */
/*==============================================================*/
create index email_auth_index on xbn_email_auth_info
(
   email
);

/*==============================================================*/
/* Index: email_auth_is_actived_index                           */
/*==============================================================*/
create index email_auth_is_actived_index on xbn_email_auth_info
(
   is_actived
);

/*==============================================================*/
/* Index: email_auth_user_id_index                              */
/*==============================================================*/
create index email_auth_user_id_index on xbn_email_auth_info
(
   user_id
);

/*==============================================================*/
/* Table: xbn_sys_area                                          */
/*==============================================================*/
create table xbn_sys_area
(
   id                   national varchar(32) not null comment '主键',
   area_code            national varchar(255) comment '地区代码',
   area_name            national varchar(255) comment '地区名称',
   parent_area_code     national varchar(255) comment '上级地区编码',
   parent_area_name     national varchar(255) comment '上级地区名称',
   level                int comment '级别',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   sort                 int comment '排序',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_sys_area comment '区域基础信息';

/*==============================================================*/
/* Index: sys_area_code_index                                   */
/*==============================================================*/
create index sys_area_code_index on xbn_sys_area
(
   area_code
);

/*==============================================================*/
/* Index: sys_area_level_index                                  */
/*==============================================================*/
create index sys_area_level_index on xbn_sys_area
(
   level
);

/*==============================================================*/
/* Index: sys_area_name_index                                   */
/*==============================================================*/
create index sys_area_name_index on xbn_sys_area
(
   area_name
);

/*==============================================================*/
/* Index: sys_parent_area_code_index                            */
/*==============================================================*/
create index sys_parent_area_code_index on xbn_sys_area
(
   parent_area_code
);

/*==============================================================*/
/* Index: sys_parent_area_name_index                            */
/*==============================================================*/
create index sys_parent_area_name_index on xbn_sys_area
(
   parent_area_name
);

/*==============================================================*/
/* Table: xbn_sys_extend                                        */
/*==============================================================*/
create table xbn_sys_extend
(
   id                   national varchar(32) not null comment '主键',
   extend_name          national varchar(255) comment '配置名称',
   extend_type          national varchar(255) comment '配置类型',
   value                national varchar(255) comment '字段取值',
   data_type            int comment '取值数据类型',
   field_1              national varchar(255) comment '扩展字段1',
   field_2              national varchar(255),
   field_3              national varchar(255),
   field_4              national varchar(255),
   field_5              national varchar(255),
   field_6              national varchar(255),
   field_7              national varchar(255),
   field_8              national varchar(255),
   field_9              national varchar(255),
   field_10             national varchar(255),
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_sys_extend comment '系统扩展配置';

/*==============================================================*/
/* Index: sys_extend_data_type_index                            */
/*==============================================================*/
create index sys_extend_data_type_index on xbn_sys_extend
(
   data_type
);

/*==============================================================*/
/* Index: sys_extend_field_10_index                             */
/*==============================================================*/
create index sys_extend_field_10_index on xbn_sys_extend
(
   field_10
);

/*==============================================================*/
/* Index: sys_extend_field_1_index                              */
/*==============================================================*/
create index sys_extend_field_1_index on xbn_sys_extend
(
   field_1
);

/*==============================================================*/
/* Index: sys_extend_field_2_index                              */
/*==============================================================*/
create index sys_extend_field_2_index on xbn_sys_extend
(
   field_2
);

/*==============================================================*/
/* Index: sys_extend_field_3_index                              */
/*==============================================================*/
create index sys_extend_field_3_index on xbn_sys_extend
(
   field_3
);

/*==============================================================*/
/* Index: sys_extend_field_4_index                              */
/*==============================================================*/
create index sys_extend_field_4_index on xbn_sys_extend
(
   field_4
);

/*==============================================================*/
/* Index: sys_extend_field_5_index                              */
/*==============================================================*/
create index sys_extend_field_5_index on xbn_sys_extend
(
   field_5
);

/*==============================================================*/
/* Index: sys_extend_field_6_index                              */
/*==============================================================*/
create index sys_extend_field_6_index on xbn_sys_extend
(
   field_6
);

/*==============================================================*/
/* Index: sys_extend_field_7_index                              */
/*==============================================================*/
create index sys_extend_field_7_index on xbn_sys_extend
(
   field_7
);

/*==============================================================*/
/* Index: sys_extend_field_8_index                              */
/*==============================================================*/
create index sys_extend_field_8_index on xbn_sys_extend
(
   field_8
);

/*==============================================================*/
/* Index: sys_extend_field_9_index                              */
/*==============================================================*/
create index sys_extend_field_9_index on xbn_sys_extend
(
   field_9
);

/*==============================================================*/
/* Index: sys_extend_name_index                                 */
/*==============================================================*/
create index sys_extend_name_index on xbn_sys_extend
(
   extend_name
);

/*==============================================================*/
/* Index: sys_extend_type_index                                 */
/*==============================================================*/
create index sys_extend_type_index on xbn_sys_extend
(
   extend_type
);

/*==============================================================*/
/* Index: sys_extend_value_index                                */
/*==============================================================*/
create index sys_extend_value_index on xbn_sys_extend
(
   value
);

/*==============================================================*/
/* Table: xbn_user                                              */
/*==============================================================*/
create table xbn_user
(
   id                   national varchar(32) not null comment '主键',
   mobile               national varchar(255) comment '手机号',
   email                national varchar(255) comment '邮箱',
   password             national varchar(255) comment '密码（MD5加密）',
   name                 national varchar(255) comment '姓名',
   gender               national varchar(1) comment '性别（0：女 1：男）',
   phone_area_code      national varchar(255) comment '电话区号',
   phone_no             national varchar(255) comment '总机号码',
   phone_extension      national varchar(255) comment '分机号码',
   is_active_email      tinyint(1) default 0 comment '是否激活邮箱',
   is_bind_mobile       tinyint(1) default 0 comment '是否绑定手机号',
   audit_status         national varchar(255) default '‘0’' comment '店铺审核状态',
   security_deposit_status varchar(255) default '‘0’' comment '保证金审核状态
            ‘0’：未提交审核 ''1'':审核中 ''2'':审核通过 ''3'':审核驳回',
   pwd_strength         national varchar(1) comment '密码强度',
   register_time        datetime comment '注册时间',
   payment_status       varchar(255) comment '保证金审核状态',
   user_status          tinyint(1) comment '会员状态',
   sku_code             varchar(255) comment '会员SKU编码',
   level_id             varchar(32) comment '会员等级',
   upc_total            int comment 'upc数量',
   ebay_list_total      int comment 'ebay刊登数量',
   group_id             varchar(32) comment '会员组ID',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint(1) default 1 comment '是否有效
            （0:无效 1: 有效）',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_user comment '会员基础信息';

/*==============================================================*/
/* Index: user_email_index                                      */
/*==============================================================*/
create index user_email_index on xbn_user
(
   email
);

/*==============================================================*/
/* Index: user_is_active_email                                  */
/*==============================================================*/
create index user_is_active_email on xbn_user
(
   is_active_email
);

/*==============================================================*/
/* Index: user_is_bind_mobile                                   */
/*==============================================================*/
create index user_is_bind_mobile on xbn_user
(
   is_bind_mobile
);

/*==============================================================*/
/* Index: user_mobile_index                                     */
/*==============================================================*/
create index user_mobile_index on xbn_user
(
   mobile
);

/*==============================================================*/
/* Table: xbn_user_login_log                                    */
/*==============================================================*/
create table xbn_user_login_log
(
   id                   varchar(32) not null comment '主键',
   user_id              varchar(32) comment '会员ID',
   login_time           datetime comment '登录时间',
   logout_time          datetime comment '登出时间',
   ip                   varchar(255) comment '登录IP',
   ip_location          varchar(255) comment 'IP所在地',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_user_login_log comment '会员登录日志';

/*==============================================================*/
/* Table: xbn_base_logistics                                    */
/*==============================================================*/
create table xbn_base_logistics
(
   id                   varchar(32) not null,
   name                 varchar(30) comment '物流名称',
   company_name         varchar(30) comment '公司名称',
   code                 varchar(20) comment '物流代码',
   product              varchar(30) comment '物流产品',
   url                  varchar(50) comment '查询网址',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '修改时间',
   is_valid             tinyint comment '是否有效',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_base_logistics comment '物流基础数据';

/*==============================================================*/
/* Table: xbn_category                                          */
/*==============================================================*/
create table xbn_category
(
   category_id          varchar(255) not null,
   en_name              varchar(255),
   cn_name              varchar(255),
   parent_category_id   varchar(255),
   level                tinyint,
   isenable             tinyint,
   isend                tinyint,
   is_valid             tinyint,
   primary key (category_id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_category comment '小笨鸟基础站点信息';

/*==============================================================*/
/* Table: xbn_category_maping                                   */
/*==============================================================*/
create table xbn_category_maping
(
   id                   varchar(255) not null,
   xbn_category_id      varchar(255),
   site_id              varchar(255),
   site_name            varchar(255),
   target_category_id   varchar(255),
   source               tinyint,
   orgin_category_id    varchar(255),
   is_valid             tinyint,
   isenable             tinyint,
   create_time          date,
   update_time          date,
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_category_maping comment '小笨鸟类目跟各个站点类目映射表';

/*==============================================================*/
/* Table: xbn_category_seller_mapping                           */
/*==============================================================*/
create table xbn_category_seller_mapping
(
   id                   int not null auto_increment comment '主键',
   category_id          varchar(255) comment '平台分类ID',
   category_name        varchar(500) comment '平台分类名称',
   platform_code        varchar(255) comment '平台编码',
   site                 varchar(255) comment '站点编码',
   seller               varchar(255) comment '卖家帐号',
   shipping_type        varchar(255) comment '发货类型',
   overseas_depot       varchar(500) comment '海外仓',
   max_list_total       int comment 'ebay最大刊登数量',
   max_list_money       decimal(10,2) comment 'ebay最大刊登金额',
   create_time          datetime default current_timestamp comment '数据创建时间',
   update_time          datetime default current_timestamp comment '数据更新时间',
   remark               varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '数据是否有效',
   primary key (id)
);

alter table xbn_category_seller_mapping comment '平台分类、卖家帐号关联表';

/*==============================================================*/
/* Index: idx_category_seller_mapping_category_id               */
/*==============================================================*/
create index idx_category_seller_mapping_category_id on xbn_category_seller_mapping
(
   category_id
);

/*==============================================================*/
/* Index: idx_category_seller_mapping_seller                    */
/*==============================================================*/
create index idx_category_seller_mapping_seller on xbn_category_seller_mapping
(
   seller
);

/*==============================================================*/
/* Index: idx_category_seller_mapping_shipping_type             */
/*==============================================================*/
create index idx_category_seller_mapping_shipping_type on xbn_category_seller_mapping
(
   shipping_type
);

/*==============================================================*/
/* Index: idx_category_seller_mapping_site                      */
/*==============================================================*/
create index idx_category_seller_mapping_site on xbn_category_seller_mapping
(
   site
);

/*==============================================================*/
/* Index: idx_category_seller_mapping_platform_code             */
/*==============================================================*/
create index idx_category_seller_mapping_platform_code on xbn_category_seller_mapping
(
   platform_code
);

/*==============================================================*/
/* Table: xbn_keyword                                           */
/*==============================================================*/
create table xbn_keyword
(
   id                   varchar(32) not null,
   keyword_value        varchar(255) comment '违禁词内容',
   platform             varchar(255) comment '所属平台',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '修改时间',
   status               tinyint comment '状态（启用、禁用）',
   exceptant_users      varchar(2000) comment '例外用户',
   is_valid             tinyint comment '是否有效',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_keyword comment '小笨鸟违禁词';

/*==============================================================*/
/* Table: xbn_qualification_site                                */
/*==============================================================*/
create table xbn_qualification_site
(
   id                   national varchar(32) not null comment '主键',
   usre_id              national varchar(32) comment '会员ID',
   site_id              national varchar(32) comment '站点ID',
   site_name            varchar(255) comment '站点名称',
   qualification_id     national varchar(32) comment '资质ID',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               national varchar(255) comment '备用字段',
   is_valid             tinyint default 1 comment '是否有效
            （0:无效 1: 有效）',
   platform_code        varchar(32) comment '所属平台',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_qualification_site comment '企业资质和站点关联关系（授权、购买）';

/*==============================================================*/
/* Index: business_category_qualification_id_index              */
/*==============================================================*/
create index business_category_qualification_id_index on xbn_qualification_site
(
   qualification_id
);

/*==============================================================*/
/* Index: business_category_user_id_index                       */
/*==============================================================*/
create index business_category_user_id_index on xbn_qualification_site
(
   usre_id
);

/*==============================================================*/
/* Table: xbn_sms_send_log                                      */
/*==============================================================*/
create table xbn_sms_send_log
(
   id                   varchar(32) not null comment '主键',
   user_id              varchar(32) comment '会员ID',
   mobile               varchar(255) comment '手机号',
   content              varchar(3000) comment '正文',
   send_time            datetime comment '发送时间',
   is_success           tinyint comment '发送状态
            （0:失败 1: 成功）',
   create_time          datetime comment '创建时间',
   update_time          datetime comment '更新时间',
   remark               varchar(255) comment '备用字段',
   is_valid             tinyint comment '是否有效
            （0:无效 1: 有效）',
   primary key (id)
)
engine = innodb
default character set = utf8
collate = utf8_general_ci;

alter table xbn_sms_send_log comment '短信发送日志';

