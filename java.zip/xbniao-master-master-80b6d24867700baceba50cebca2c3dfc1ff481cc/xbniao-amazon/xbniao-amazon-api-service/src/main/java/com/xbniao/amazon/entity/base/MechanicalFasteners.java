package com.xbniao.amazon.entity.base;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.NormalizedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;



/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}Color" minOccurs="0"/>
 *         &lt;element ref="{}CompatibleGrooveDepth" minOccurs="0"/>
 *         &lt;element ref="{}CompatibleGrooveDiameter" minOccurs="0"/>
 *         &lt;element ref="{}CompatibleGrooveWidth" minOccurs="0"/>
 *         &lt;element ref="{}CompatibleWithInsideDiameter" minOccurs="0"/>
 *         &lt;element ref="{}CompatibleWithPipeSize" minOccurs="0"/>
 *         &lt;element ref="{}CompatibleWithTorxWrench" minOccurs="0"/>
 *         &lt;element ref="{}CountryOfOrigin" minOccurs="0"/>
 *         &lt;element ref="{}DriveSystem" minOccurs="0"/>
 *         &lt;element ref="{}ExteriorFinish" minOccurs="0"/>
 *         &lt;element ref="{}FastenerThreadCount" minOccurs="0"/>
 *         &lt;element ref="{}GradeRating" minOccurs="0"/>
 *         &lt;element ref="{}HeadDiameter" minOccurs="0"/>
 *         &lt;element ref="{}HeadDiameterTolerance" minOccurs="0"/>
 *         &lt;element ref="{}HeadHeight" minOccurs="0"/>
 *         &lt;element ref="{}HeadHeightTolerance" minOccurs="0"/>
 *         &lt;element ref="{}IndentationHardness" minOccurs="0"/>
 *         &lt;element ref="{}InsideDiameter" minOccurs="0"/>
 *         &lt;element ref="{}InsideDiameterTolerance" minOccurs="0"/>
 *         &lt;element ref="{}InsideThreadSize" minOccurs="0"/>
 *         &lt;element ref="{}ItemDepth" minOccurs="0"/>
 *         &lt;element ref="{}ItemDiameter" minOccurs="0"/>
 *         &lt;element ref="{}ItemThickness" minOccurs="0"/>
 *         &lt;element ref="{}ItemThicknessTolerance" minOccurs="0"/>
 *         &lt;element ref="{}LowerTemperatureRating" minOccurs="0"/>
 *         &lt;element ref="{}MagneticPullCapacity" minOccurs="0"/>
 *         &lt;element name="MaterialType" type="{}LongString" minOccurs="0"/>
 *         &lt;element ref="{}MaximumCompatibleThickness" minOccurs="0"/>
 *         &lt;element ref="{}MaximumDoubleShearStrength" minOccurs="0"/>
 *         &lt;element ref="{}MaxShearStrength" minOccurs="0"/>
 *         &lt;element ref="{}MeasurementSystem" minOccurs="0"/>
 *         &lt;element ref="{}MinimumCompatibleThickness" minOccurs="0"/>
 *         &lt;element ref="{}MinimumEmbedmentDepth" minOccurs="0"/>
 *         &lt;element ref="{}Model" minOccurs="0"/>
 *         &lt;element ref="{}NominalOutsideDiameter" minOccurs="0"/>
 *         &lt;element ref="{}NumberOfStarts" minOccurs="0"/>
 *         &lt;element ref="{}NumberOfTurns" minOccurs="0"/>
 *         &lt;element ref="{}OutsideThreadSize" minOccurs="0"/>
 *         &lt;element ref="{}PointMaterialType" minOccurs="0"/>
 *         &lt;element ref="{}ScrewHeadStyle" minOccurs="0"/>
 *         &lt;element ref="{}ScrewPointStyle" minOccurs="0"/>
 *         &lt;element ref="{}SelfLockingMechanismType" minOccurs="0"/>
 *         &lt;element ref="{}ShoulderDiameter" minOccurs="0"/>
 *         &lt;element ref="{}ShoulderDiameterTolerance" minOccurs="0"/>
 *         &lt;element ref="{}ShoulderLength" minOccurs="0"/>
 *         &lt;element ref="{}ShoulderLengthTolerance" minOccurs="0"/>
 *         &lt;element ref="{}SizeName" minOccurs="0"/>
 *         &lt;element ref="{}SpecificationMet" maxOccurs="5" minOccurs="0"/>
 *         &lt;element ref="{}ThreadCoverage" minOccurs="0"/>
 *         &lt;element ref="{}ThreadLength" minOccurs="0"/>
 *         &lt;element ref="{}ThreadPitch" minOccurs="0"/>
 *         &lt;element ref="{}ThreadSize" minOccurs="0"/>
 *         &lt;element ref="{}ThreadStyle" minOccurs="0"/>
 *         &lt;element ref="{}ThreadType" minOccurs="0"/>
 *         &lt;element ref="{}UncompressedDiameter" minOccurs="0"/>
 *         &lt;element ref="{}UpperTemperatureRating" minOccurs="0"/>
 *         &lt;element ref="{}WasherType" minOccurs="0"/>
 *         &lt;element ref="{}WingSpan" minOccurs="0"/>
 *         &lt;element ref="{}WorkingLoadLimit" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "color",
    "compatibleGrooveDepth",
    "compatibleGrooveDiameter",
    "compatibleGrooveWidth",
    "compatibleWithInsideDiameter",
    "compatibleWithPipeSize",
    "compatibleWithTorxWrench",
    "countryOfOrigin",
    "driveSystem",
    "exteriorFinish",
    "fastenerThreadCount",
    "gradeRating",
    "headDiameter",
    "headDiameterTolerance",
    "headHeight",
    "headHeightTolerance",
    "indentationHardness",
    "insideDiameter",
    "insideDiameterTolerance",
    "insideThreadSize",
    "itemDepth",
    "itemDiameter",
    "itemThickness",
    "itemThicknessTolerance",
    "lowerTemperatureRating",
    "magneticPullCapacity",
    "materialType",
    "maximumCompatibleThickness",
    "maximumDoubleShearStrength",
    "maxShearStrength",
    "measurementSystem",
    "minimumCompatibleThickness",
    "minimumEmbedmentDepth",
    "model",
    "nominalOutsideDiameter",
    "numberOfStarts",
    "numberOfTurns",
    "outsideThreadSize",
    "pointMaterialType",
    "screwHeadStyle",
    "screwPointStyle",
    "selfLockingMechanismType",
    "shoulderDiameter",
    "shoulderDiameterTolerance",
    "shoulderLength",
    "shoulderLengthTolerance",
    "sizeName",
    "specificationMet",
    "threadCoverage",
    "threadLength",
    "threadPitch",
    "threadSize",
    "threadStyle",
    "threadType",
    "uncompressedDiameter",
    "upperTemperatureRating",
    "washerType",
    "wingSpan",
    "workingLoadLimit"
})
@XmlRootElement(name = "MechanicalFasteners")
public class MechanicalFasteners {
    @XmlElement(name = "Color")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String color;
    @XmlElement(name = "CompatibleGrooveDepth")
    protected LengthDimension compatibleGrooveDepth;
    @XmlElement(name = "CompatibleGrooveDiameter")
    protected LengthDimension compatibleGrooveDiameter;
    @XmlElement(name = "CompatibleGrooveWidth")
    protected LengthDimension compatibleGrooveWidth;
    @XmlElement(name = "CompatibleWithInsideDiameter")
    protected LengthDimension compatibleWithInsideDiameter;
    @XmlElement(name = "CompatibleWithPipeSize")
    protected Boolean compatibleWithPipeSize;
    @XmlElement(name = "CompatibleWithTorxWrench")
    protected Boolean compatibleWithTorxWrench;
    @XmlElement(name = "CountryOfOrigin")
    protected String countryOfOrigin;
    @XmlElement(name = "DriveSystem")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String driveSystem;
    @XmlElement(name = "ExteriorFinish")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String exteriorFinish;
    @XmlElement(name = "FastenerThreadCount")
    protected BigInteger fastenerThreadCount;
    @XmlElement(name = "GradeRating")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String gradeRating;
    @XmlElement(name = "HeadDiameter")
    protected LengthDimension headDiameter;
    @XmlElement(name = "HeadDiameterTolerance")
    protected LengthDimension headDiameterTolerance;
    @XmlElement(name = "HeadHeight")
    protected LengthDimension headHeight;
    @XmlElement(name = "HeadHeightTolerance")
    protected LengthDimension headHeightTolerance;
    @XmlElement(name = "IndentationHardness")
    protected HardnessDimension indentationHardness;
    @XmlElement(name = "InsideDiameter")
    protected LengthDimension insideDiameter;
    @XmlElement(name = "InsideDiameterTolerance")
    protected LengthDimension insideDiameterTolerance;
    @XmlElement(name = "InsideThreadSize")
    protected LengthDimension insideThreadSize;
    @XmlElement(name = "ItemDepth")
    protected LengthDimension itemDepth;
    @XmlElement(name = "ItemDiameter")
    protected LengthDimension itemDiameter;
    @XmlElement(name = "ItemThickness")
    protected LengthDimension itemThickness;
    @XmlElement(name = "ItemThicknessTolerance")
    protected LengthDimension itemThicknessTolerance;
    @XmlElement(name = "LowerTemperatureRating")
    protected TemperatureDimension lowerTemperatureRating;
    @XmlElement(name = "MagneticPullCapacity")
    protected WeightDimension magneticPullCapacity;
    @XmlElement(name = "MaterialType")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String materialType;
    @XmlElement(name = "MaximumCompatibleThickness")
    protected LengthDimension maximumCompatibleThickness;
    @XmlElement(name = "MaximumDoubleShearStrength")
    protected ShearStrengthDimension maximumDoubleShearStrength;
    @XmlElement(name = "MaxShearStrength")
    protected ShearStrengthDimension maxShearStrength;
    @XmlElement(name = "MeasurementSystem")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String measurementSystem;
    @XmlElement(name = "MinimumCompatibleThickness")
    protected LengthDimension minimumCompatibleThickness;
    @XmlElement(name = "MinimumEmbedmentDepth")
    protected LengthDimension minimumEmbedmentDepth;
    @XmlElement(name = "Model")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String model;
    @XmlElement(name = "NominalOutsideDiameter")
    protected LengthDimension nominalOutsideDiameter;
    @XmlElement(name = "NumberOfStarts")
    protected BigInteger numberOfStarts;
    @XmlElement(name = "NumberOfTurns")
    protected BigInteger numberOfTurns;
    @XmlElement(name = "OutsideThreadSize")
    protected LengthDimension outsideThreadSize;
    @XmlElement(name = "PointMaterialType")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String pointMaterialType;
    @XmlElement(name = "ScrewHeadStyle")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String screwHeadStyle;
    @XmlElement(name = "ScrewPointStyle")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String screwPointStyle;
    @XmlElement(name = "SelfLockingMechanismType")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String selfLockingMechanismType;
    @XmlElement(name = "ShoulderDiameter")
    protected LengthDimension shoulderDiameter;
    @XmlElement(name = "ShoulderDiameterTolerance")
    protected LengthDimension shoulderDiameterTolerance;
    @XmlElement(name = "ShoulderLength")
    protected LengthDimension shoulderLength;
    @XmlElement(name = "ShoulderLengthTolerance")
    protected LengthDimension shoulderLengthTolerance;
    @XmlElement(name = "SizeName")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String sizeName;
    @XmlElement(name = "SpecificationMet")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected List<String> specificationMet;
    @XmlElement(name = "ThreadCoverage")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String threadCoverage;
    @XmlElement(name = "ThreadLength")
    protected LengthDimension threadLength;
    @XmlElement(name = "ThreadPitch")
    protected LengthDimension threadPitch;
    @XmlElement(name = "ThreadSize")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String threadSize;
    @XmlElement(name = "ThreadStyle")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String threadStyle;
    @XmlElement(name = "ThreadType")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String threadType;
    @XmlElement(name = "UncompressedDiameter")
    protected LengthDimension uncompressedDiameter;
    @XmlElement(name = "UpperTemperatureRating")
    protected TemperatureDimension upperTemperatureRating;
    @XmlElement(name = "WasherType")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String washerType;
    @XmlElement(name = "WingSpan")
    protected LengthDimension wingSpan;
    @XmlElement(name = "WorkingLoadLimit")
    protected WeightDimension workingLoadLimit;
    
    

    public Boolean getCompatibleWithPipeSize() {
		return compatibleWithPipeSize;
	}

	public Boolean getCompatibleWithTorxWrench() {
		return compatibleWithTorxWrench;
	}

	public void setSpecificationMet(List<String> specificationMet) {
		this.specificationMet = specificationMet;
	}

	/**
     * Gets the value of the color property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColor() {
        return color;
    }

    /**
     * Sets the value of the color property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColor(String value) {
        this.color = value;
    }

    /**
     * Gets the value of the compatibleGrooveDepth property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getCompatibleGrooveDepth() {
        return compatibleGrooveDepth;
    }

    /**
     * Sets the value of the compatibleGrooveDepth property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setCompatibleGrooveDepth(LengthDimension value) {
        this.compatibleGrooveDepth = value;
    }

    /**
     * Gets the value of the compatibleGrooveDiameter property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getCompatibleGrooveDiameter() {
        return compatibleGrooveDiameter;
    }

    /**
     * Sets the value of the compatibleGrooveDiameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setCompatibleGrooveDiameter(LengthDimension value) {
        this.compatibleGrooveDiameter = value;
    }

    /**
     * Gets the value of the compatibleGrooveWidth property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getCompatibleGrooveWidth() {
        return compatibleGrooveWidth;
    }

    /**
     * Sets the value of the compatibleGrooveWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setCompatibleGrooveWidth(LengthDimension value) {
        this.compatibleGrooveWidth = value;
    }

    /**
     * Gets the value of the compatibleWithInsideDiameter property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getCompatibleWithInsideDiameter() {
        return compatibleWithInsideDiameter;
    }

    /**
     * Sets the value of the compatibleWithInsideDiameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setCompatibleWithInsideDiameter(LengthDimension value) {
        this.compatibleWithInsideDiameter = value;
    }

    /**
     * Gets the value of the compatibleWithPipeSize property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCompatibleWithPipeSize() {
        return compatibleWithPipeSize;
    }

    /**
     * Sets the value of the compatibleWithPipeSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCompatibleWithPipeSize(Boolean value) {
        this.compatibleWithPipeSize = value;
    }

    /**
     * Gets the value of the compatibleWithTorxWrench property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCompatibleWithTorxWrench() {
        return compatibleWithTorxWrench;
    }

    /**
     * Sets the value of the compatibleWithTorxWrench property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCompatibleWithTorxWrench(Boolean value) {
        this.compatibleWithTorxWrench = value;
    }

    /**
     * Gets the value of the countryOfOrigin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryOfOrigin() {
        return countryOfOrigin;
    }

    /**
     * Sets the value of the countryOfOrigin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryOfOrigin(String value) {
        this.countryOfOrigin = value;
    }

    /**
     * Gets the value of the driveSystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDriveSystem() {
        return driveSystem;
    }

    /**
     * Sets the value of the driveSystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDriveSystem(String value) {
        this.driveSystem = value;
    }

    /**
     * Gets the value of the exteriorFinish property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExteriorFinish() {
        return exteriorFinish;
    }

    /**
     * Sets the value of the exteriorFinish property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExteriorFinish(String value) {
        this.exteriorFinish = value;
    }

    /**
     * Gets the value of the fastenerThreadCount property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getFastenerThreadCount() {
        return fastenerThreadCount;
    }

    /**
     * Sets the value of the fastenerThreadCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setFastenerThreadCount(BigInteger value) {
        this.fastenerThreadCount = value;
    }

    /**
     * Gets the value of the gradeRating property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGradeRating() {
        return gradeRating;
    }

    /**
     * Sets the value of the gradeRating property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGradeRating(String value) {
        this.gradeRating = value;
    }

    /**
     * Gets the value of the headDiameter property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getHeadDiameter() {
        return headDiameter;
    }

    /**
     * Sets the value of the headDiameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setHeadDiameter(LengthDimension value) {
        this.headDiameter = value;
    }

    /**
     * Gets the value of the headDiameterTolerance property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getHeadDiameterTolerance() {
        return headDiameterTolerance;
    }

    /**
     * Sets the value of the headDiameterTolerance property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setHeadDiameterTolerance(LengthDimension value) {
        this.headDiameterTolerance = value;
    }

    /**
     * Gets the value of the headHeight property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getHeadHeight() {
        return headHeight;
    }

    /**
     * Sets the value of the headHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setHeadHeight(LengthDimension value) {
        this.headHeight = value;
    }

    /**
     * Gets the value of the headHeightTolerance property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getHeadHeightTolerance() {
        return headHeightTolerance;
    }

    /**
     * Sets the value of the headHeightTolerance property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setHeadHeightTolerance(LengthDimension value) {
        this.headHeightTolerance = value;
    }

    /**
     * Gets the value of the indentationHardness property.
     * 
     * @return
     *     possible object is
     *     {@link HardnessDimension }
     *     
     */
    public HardnessDimension getIndentationHardness() {
        return indentationHardness;
    }

    /**
     * Sets the value of the indentationHardness property.
     * 
     * @param value
     *     allowed object is
     *     {@link HardnessDimension }
     *     
     */
    public void setIndentationHardness(HardnessDimension value) {
        this.indentationHardness = value;
    }

    /**
     * Gets the value of the insideDiameter property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getInsideDiameter() {
        return insideDiameter;
    }

    /**
     * Sets the value of the insideDiameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setInsideDiameter(LengthDimension value) {
        this.insideDiameter = value;
    }

    /**
     * Gets the value of the insideDiameterTolerance property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getInsideDiameterTolerance() {
        return insideDiameterTolerance;
    }

    /**
     * Sets the value of the insideDiameterTolerance property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setInsideDiameterTolerance(LengthDimension value) {
        this.insideDiameterTolerance = value;
    }

    /**
     * Gets the value of the insideThreadSize property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getInsideThreadSize() {
        return insideThreadSize;
    }

    /**
     * Sets the value of the insideThreadSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setInsideThreadSize(LengthDimension value) {
        this.insideThreadSize = value;
    }

    /**
     * Gets the value of the itemDepth property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getItemDepth() {
        return itemDepth;
    }

    /**
     * Sets the value of the itemDepth property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setItemDepth(LengthDimension value) {
        this.itemDepth = value;
    }

    /**
     * Gets the value of the itemDiameter property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getItemDiameter() {
        return itemDiameter;
    }

    /**
     * Sets the value of the itemDiameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setItemDiameter(LengthDimension value) {
        this.itemDiameter = value;
    }

    /**
     * Gets the value of the itemThickness property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getItemThickness() {
        return itemThickness;
    }

    /**
     * Sets the value of the itemThickness property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setItemThickness(LengthDimension value) {
        this.itemThickness = value;
    }

    /**
     * Gets the value of the itemThicknessTolerance property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getItemThicknessTolerance() {
        return itemThicknessTolerance;
    }

    /**
     * Sets the value of the itemThicknessTolerance property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setItemThicknessTolerance(LengthDimension value) {
        this.itemThicknessTolerance = value;
    }

    /**
     * Gets the value of the lowerTemperatureRating property.
     * 
     * @return
     *     possible object is
     *     {@link TemperatureDimension }
     *     
     */
    public TemperatureDimension getLowerTemperatureRating() {
        return lowerTemperatureRating;
    }

    /**
     * Sets the value of the lowerTemperatureRating property.
     * 
     * @param value
     *     allowed object is
     *     {@link TemperatureDimension }
     *     
     */
    public void setLowerTemperatureRating(TemperatureDimension value) {
        this.lowerTemperatureRating = value;
    }

    /**
     * Gets the value of the magneticPullCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link WeightDimension }
     *     
     */
    public WeightDimension getMagneticPullCapacity() {
        return magneticPullCapacity;
    }

    /**
     * Sets the value of the magneticPullCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link WeightDimension }
     *     
     */
    public void setMagneticPullCapacity(WeightDimension value) {
        this.magneticPullCapacity = value;
    }

    /**
     * Gets the value of the materialType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaterialType() {
        return materialType;
    }

    /**
     * Sets the value of the materialType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaterialType(String value) {
        this.materialType = value;
    }

    /**
     * Gets the value of the maximumCompatibleThickness property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getMaximumCompatibleThickness() {
        return maximumCompatibleThickness;
    }

    /**
     * Sets the value of the maximumCompatibleThickness property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setMaximumCompatibleThickness(LengthDimension value) {
        this.maximumCompatibleThickness = value;
    }

    /**
     * Gets the value of the maximumDoubleShearStrength property.
     * 
     * @return
     *     possible object is
     *     {@link ShearStrengthDimension }
     *     
     */
    public ShearStrengthDimension getMaximumDoubleShearStrength() {
        return maximumDoubleShearStrength;
    }

    /**
     * Sets the value of the maximumDoubleShearStrength property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShearStrengthDimension }
     *     
     */
    public void setMaximumDoubleShearStrength(ShearStrengthDimension value) {
        this.maximumDoubleShearStrength = value;
    }

    /**
     * Gets the value of the maxShearStrength property.
     * 
     * @return
     *     possible object is
     *     {@link ShearStrengthDimension }
     *     
     */
    public ShearStrengthDimension getMaxShearStrength() {
        return maxShearStrength;
    }

    /**
     * Sets the value of the maxShearStrength property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShearStrengthDimension }
     *     
     */
    public void setMaxShearStrength(ShearStrengthDimension value) {
        this.maxShearStrength = value;
    }

    /**
     * Gets the value of the measurementSystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeasurementSystem() {
        return measurementSystem;
    }

    /**
     * Sets the value of the measurementSystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeasurementSystem(String value) {
        this.measurementSystem = value;
    }

    /**
     * Gets the value of the minimumCompatibleThickness property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getMinimumCompatibleThickness() {
        return minimumCompatibleThickness;
    }

    /**
     * Sets the value of the minimumCompatibleThickness property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setMinimumCompatibleThickness(LengthDimension value) {
        this.minimumCompatibleThickness = value;
    }

    /**
     * Gets the value of the minimumEmbedmentDepth property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getMinimumEmbedmentDepth() {
        return minimumEmbedmentDepth;
    }

    /**
     * Sets the value of the minimumEmbedmentDepth property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setMinimumEmbedmentDepth(LengthDimension value) {
        this.minimumEmbedmentDepth = value;
    }

    /**
     * Gets the value of the model property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the value of the model property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModel(String value) {
        this.model = value;
    }

    /**
     * Gets the value of the nominalOutsideDiameter property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getNominalOutsideDiameter() {
        return nominalOutsideDiameter;
    }

    /**
     * Sets the value of the nominalOutsideDiameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setNominalOutsideDiameter(LengthDimension value) {
        this.nominalOutsideDiameter = value;
    }

    /**
     * Gets the value of the numberOfStarts property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumberOfStarts() {
        return numberOfStarts;
    }

    /**
     * Sets the value of the numberOfStarts property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumberOfStarts(BigInteger value) {
        this.numberOfStarts = value;
    }

    /**
     * Gets the value of the numberOfTurns property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumberOfTurns() {
        return numberOfTurns;
    }

    /**
     * Sets the value of the numberOfTurns property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumberOfTurns(BigInteger value) {
        this.numberOfTurns = value;
    }

    /**
     * Gets the value of the outsideThreadSize property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getOutsideThreadSize() {
        return outsideThreadSize;
    }

    /**
     * Sets the value of the outsideThreadSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setOutsideThreadSize(LengthDimension value) {
        this.outsideThreadSize = value;
    }

    /**
     * Gets the value of the pointMaterialType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPointMaterialType() {
        return pointMaterialType;
    }

    /**
     * Sets the value of the pointMaterialType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPointMaterialType(String value) {
        this.pointMaterialType = value;
    }

    /**
     * Gets the value of the screwHeadStyle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScrewHeadStyle() {
        return screwHeadStyle;
    }

    /**
     * Sets the value of the screwHeadStyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScrewHeadStyle(String value) {
        this.screwHeadStyle = value;
    }

    /**
     * Gets the value of the screwPointStyle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScrewPointStyle() {
        return screwPointStyle;
    }

    /**
     * Sets the value of the screwPointStyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScrewPointStyle(String value) {
        this.screwPointStyle = value;
    }

    /**
     * Gets the value of the selfLockingMechanismType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSelfLockingMechanismType() {
        return selfLockingMechanismType;
    }

    /**
     * Sets the value of the selfLockingMechanismType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSelfLockingMechanismType(String value) {
        this.selfLockingMechanismType = value;
    }

    /**
     * Gets the value of the shoulderDiameter property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getShoulderDiameter() {
        return shoulderDiameter;
    }

    /**
     * Sets the value of the shoulderDiameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setShoulderDiameter(LengthDimension value) {
        this.shoulderDiameter = value;
    }

    /**
     * Gets the value of the shoulderDiameterTolerance property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getShoulderDiameterTolerance() {
        return shoulderDiameterTolerance;
    }

    /**
     * Sets the value of the shoulderDiameterTolerance property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setShoulderDiameterTolerance(LengthDimension value) {
        this.shoulderDiameterTolerance = value;
    }

    /**
     * Gets the value of the shoulderLength property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getShoulderLength() {
        return shoulderLength;
    }

    /**
     * Sets the value of the shoulderLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setShoulderLength(LengthDimension value) {
        this.shoulderLength = value;
    }

    /**
     * Gets the value of the shoulderLengthTolerance property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getShoulderLengthTolerance() {
        return shoulderLengthTolerance;
    }

    /**
     * Sets the value of the shoulderLengthTolerance property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setShoulderLengthTolerance(LengthDimension value) {
        this.shoulderLengthTolerance = value;
    }

    /**
     * Gets the value of the sizeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSizeName() {
        return sizeName;
    }

    /**
     * Sets the value of the sizeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSizeName(String value) {
        this.sizeName = value;
    }

    /**
     * Gets the value of the specificationMet property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the specificationMet property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSpecificationMet().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getSpecificationMet() {
        if (specificationMet == null) {
            specificationMet = new ArrayList<String>();
        }
        return this.specificationMet;
    }

    /**
     * Gets the value of the threadCoverage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThreadCoverage() {
        return threadCoverage;
    }

    /**
     * Sets the value of the threadCoverage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThreadCoverage(String value) {
        this.threadCoverage = value;
    }

    /**
     * Gets the value of the threadLength property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getThreadLength() {
        return threadLength;
    }

    /**
     * Sets the value of the threadLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setThreadLength(LengthDimension value) {
        this.threadLength = value;
    }

    /**
     * Gets the value of the threadPitch property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getThreadPitch() {
        return threadPitch;
    }

    /**
     * Sets the value of the threadPitch property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setThreadPitch(LengthDimension value) {
        this.threadPitch = value;
    }

    /**
     * Gets the value of the threadSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThreadSize() {
        return threadSize;
    }

    /**
     * Sets the value of the threadSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThreadSize(String value) {
        this.threadSize = value;
    }

    /**
     * Gets the value of the threadStyle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThreadStyle() {
        return threadStyle;
    }

    /**
     * Sets the value of the threadStyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThreadStyle(String value) {
        this.threadStyle = value;
    }

    /**
     * Gets the value of the threadType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThreadType() {
        return threadType;
    }

    /**
     * Sets the value of the threadType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThreadType(String value) {
        this.threadType = value;
    }

    /**
     * Gets the value of the uncompressedDiameter property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getUncompressedDiameter() {
        return uncompressedDiameter;
    }

    /**
     * Sets the value of the uncompressedDiameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setUncompressedDiameter(LengthDimension value) {
        this.uncompressedDiameter = value;
    }

    /**
     * Gets the value of the upperTemperatureRating property.
     * 
     * @return
     *     possible object is
     *     {@link TemperatureDimension }
     *     
     */
    public TemperatureDimension getUpperTemperatureRating() {
        return upperTemperatureRating;
    }

    /**
     * Sets the value of the upperTemperatureRating property.
     * 
     * @param value
     *     allowed object is
     *     {@link TemperatureDimension }
     *     
     */
    public void setUpperTemperatureRating(TemperatureDimension value) {
        this.upperTemperatureRating = value;
    }

    /**
     * Gets the value of the washerType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWasherType() {
        return washerType;
    }

    /**
     * Sets the value of the washerType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWasherType(String value) {
        this.washerType = value;
    }

    /**
     * Gets the value of the wingSpan property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getWingSpan() {
        return wingSpan;
    }

    /**
     * Sets the value of the wingSpan property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setWingSpan(LengthDimension value) {
        this.wingSpan = value;
    }

    /**
     * Gets the value of the workingLoadLimit property.
     * 
     * @return
     *     possible object is
     *     {@link WeightDimension }
     *     
     */
    public WeightDimension getWorkingLoadLimit() {
        return workingLoadLimit;
    }

    /**
     * Sets the value of the workingLoadLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link WeightDimension }
     *     
     */
    public void setWorkingLoadLimit(WeightDimension value) {
        this.workingLoadLimit = value;
    }


}
