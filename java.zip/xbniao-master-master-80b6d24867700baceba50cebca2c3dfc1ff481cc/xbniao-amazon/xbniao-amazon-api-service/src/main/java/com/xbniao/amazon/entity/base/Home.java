package com.xbniao.amazon.entity.base;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.NormalizedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.xbniao.amazon.enumtype.other.BatteryCellTypeValues;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}Battery" minOccurs="0"/>
 *         &lt;element name="ColorMap" type="{}StringNotNull" minOccurs="0"/>
 *         &lt;element name="Finish" type="{}StringNotNull" minOccurs="0"/>
 *         &lt;element name="IsStainResistant" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="LightSourceType" type="{}StringNotNull" minOccurs="0"/>
 *         &lt;element name="Material" type="{}StringNotNull" minOccurs="0"/>
 *         &lt;element name="MaximumCoverageArea" type="{}AreaDimensionOptionalUnit" minOccurs="0"/>
 *         &lt;element name="NumberOfSets" type="{}TenDigitInteger" minOccurs="0"/>
 *         &lt;element name="OutputCapacity" type="{}VolumeRateDimension" minOccurs="0"/>
 *         &lt;element name="PieceCount" type="{}PositiveInteger" minOccurs="0"/>
 *         &lt;element name="Shape" type="{}StringNotNull" minOccurs="0"/>
 *         &lt;element name="ThreadCount" type="{}PositiveInteger" minOccurs="0"/>
 *         &lt;element name="TowelWeight" type="{}WeightDimension" minOccurs="0"/>
 *         &lt;element name="VariationData" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="VariationTheme" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;enumeration value="Size"/>
 *                         &lt;enumeration value="Color"/>
 *                         &lt;enumeration value="Scent"/>
 *                         &lt;enumeration value="Size-Color"/>
 *                         &lt;enumeration value="Size-Scent"/>
 *                         &lt;enumeration value="DisplayLength-DisplayWidth"/>
 *                         &lt;enumeration value="DisplayLength-Material"/>
 *                         &lt;enumeration value="DisplayLength-Size"/>
 *                         &lt;enumeration value="DisplayLength-Color"/>
 *                         &lt;enumeration value="DisplayLength-DisplayHeight"/>
 *                         &lt;enumeration value="DisplayWidth-Material"/>
 *                         &lt;enumeration value="DisplayWidth-Size"/>
 *                         &lt;enumeration value="DisplayWidth-Color"/>
 *                         &lt;enumeration value="DisplayWidth-DisplayHeight"/>
 *                         &lt;enumeration value="ItemPackageQuantity-Material"/>
 *                         &lt;enumeration value="ItemPackageQuantity-Size"/>
 *                         &lt;enumeration value="ItemPackageQuantity-Color"/>
 *                         &lt;enumeration value="ItemPackageQuantity-DisplayHeight"/>
 *                         &lt;enumeration value="DisplayWeight-ItemPackageQuantity"/>
 *                         &lt;enumeration value="DisplayWeight-Material"/>
 *                         &lt;enumeration value="DisplayWeight-Size"/>
 *                         &lt;enumeration value="DisplayWeight-Color"/>
 *                         &lt;enumeration value="DisplayWeight-DisplayHeight"/>
 *                         &lt;enumeration value="Material-DisplayLength"/>
 *                         &lt;enumeration value="Material-DisplayWidth"/>
 *                         &lt;enumeration value="Material-Size"/>
 *                         &lt;enumeration value="Material-Color"/>
 *                         &lt;enumeration value="Material-DisplayHeight"/>
 *                         &lt;enumeration value="Size-DisplayLength"/>
 *                         &lt;enumeration value="Size-DisplayWidth"/>
 *                         &lt;enumeration value="Size-DisplayWeight"/>
 *                         &lt;enumeration value="Size-Material"/>
 *                         &lt;enumeration value="Size-Color"/>
 *                         &lt;enumeration value="Size-DisplayHeight"/>
 *                         &lt;enumeration value="Color-DisplayLength"/>
 *                         &lt;enumeration value="Color-DisplayWidth"/>
 *                         &lt;enumeration value="Color-ItemPackageQuantity"/>
 *                         &lt;enumeration value="Color-DisplayWeight"/>
 *                         &lt;enumeration value="Color-Material"/>
 *                         &lt;enumeration value="Color-Size"/>
 *                         &lt;enumeration value="Color-DisplayHeight"/>
 *                         &lt;enumeration value="DisplayHeight"/>
 *                         &lt;enumeration value="Material"/>
 *                         &lt;enumeration value="DisplayWeight"/>
 *                         &lt;enumeration value="DisplayLength"/>
 *                         &lt;enumeration value="ItemPackageQuantity"/>
 *                         &lt;enumeration value="DisplayLength-PatternName"/>
 *                         &lt;enumeration value="DisplayLength-StyleName"/>
 *                         &lt;enumeration value="DisplayWidth-PatternName"/>
 *                         &lt;enumeration value="DisplayWidth-StyleName"/>
 *                         &lt;enumeration value="Occasion-PatternName"/>
 *                         &lt;enumeration value="Occasion-ItemPackageQuantity"/>
 *                         &lt;enumeration value="Occasion-Material"/>
 *                         &lt;enumeration value="Occasion-StyleName"/>
 *                         &lt;enumeration value="Occasion-Size"/>
 *                         &lt;enumeration value="Occasion-Color"/>
 *                         &lt;enumeration value="Occasion-DisplayHeight"/>
 *                         &lt;enumeration value="PatternName-DisplayLength"/>
 *                         &lt;enumeration value="PatternName-DisplayWidth"/>
 *                         &lt;enumeration value="PatternName-Occasion"/>
 *                         &lt;enumeration value="PatternName-Material"/>
 *                         &lt;enumeration value="PatternName-StyleName"/>
 *                         &lt;enumeration value="PatternName-Size"/>
 *                         &lt;enumeration value="PatternName-Color"/>
 *                         &lt;enumeration value="PatternName-DisplayHeight"/>
 *                         &lt;enumeration value="MatteStyle-Material"/>
 *                         &lt;enumeration value="MatteStyle-StyleName"/>
 *                         &lt;enumeration value="MatteStyle-Size"/>
 *                         &lt;enumeration value="MatteStyle-Color"/>
 *                         &lt;enumeration value="ItemPackageQuantity-Occasion"/>
 *                         &lt;enumeration value="ItemPackageQuantity-StyleName"/>
 *                         &lt;enumeration value="DisplayWeight-StyleName"/>
 *                         &lt;enumeration value="Material-PatternName"/>
 *                         &lt;enumeration value="Material-MatteStyle"/>
 *                         &lt;enumeration value="Material-StyleName"/>
 *                         &lt;enumeration value="StyleName-DisplayLength"/>
 *                         &lt;enumeration value="StyleName-DisplayWidth"/>
 *                         &lt;enumeration value="StyleName-Occasion"/>
 *                         &lt;enumeration value="StyleName-PatternName"/>
 *                         &lt;enumeration value="StyleName-DisplayWeight"/>
 *                         &lt;enumeration value="StyleName-Material"/>
 *                         &lt;enumeration value="StyleName-Size"/>
 *                         &lt;enumeration value="StyleName-Color"/>
 *                         &lt;enumeration value="Size-Occasion"/>
 *                         &lt;enumeration value="Size-PatternName"/>
 *                         &lt;enumeration value="Size-MatteStyle"/>
 *                         &lt;enumeration value="Size-StyleName"/>
 *                         &lt;enumeration value="Color-Occasion"/>
 *                         &lt;enumeration value="Color-PatternName"/>
 *                         &lt;enumeration value="Color-MatteStyle"/>
 *                         &lt;enumeration value="Color-StyleName"/>
 *                         &lt;enumeration value="MatteStyle"/>
 *                         &lt;enumeration value="PatternName"/>
 *                         &lt;enumeration value="Occasion"/>
 *                         &lt;enumeration value="StyleName"/>
 *                         &lt;enumeration value="CustomerPackageType"/>
 *                         &lt;enumeration value="ColorName-CustomerPackageType"/>
 *                         &lt;enumeration value="SizeName-CustomerPackageType"/>
 *                         &lt;enumeration value="SizeName-ColorName-CustomerPackageType"/>
 *                         &lt;enumeration value="StyleName-CustomerPackageType"/>
 *                         &lt;enumeration value="SizeName-StyleName-CustomerPackageType"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="Size" type="{}StringNotNull" minOccurs="0"/>
 *                   &lt;element name="Color" type="{}StringNotNull" minOccurs="0"/>
 *                   &lt;element name="Scent" type="{}StringNotNull" minOccurs="0"/>
 *                   &lt;element name="CustomerPackageType" type="{}StringNotNull" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Wattage" type="{}WattageDimensionOptionalUnit" minOccurs="0"/>
 *         &lt;element name="InnerMaterialType" type="{}StringNotNull" minOccurs="0"/>
 *         &lt;element name="ItemDiameter" type="{}LengthDimension" minOccurs="0"/>
 *         &lt;element name="BatteryCellComposition" type="{}BatteryCellTypeValues" minOccurs="0"/>
 *         &lt;element name="BatteryFormFactor" type="{}StringNotNull" minOccurs="0"/>
 *         &lt;element name="PaintType" type="{}StringNotNull" minOccurs="0"/>
 *         &lt;element name="CustomerRestrictionType" type="{}StringNotNull" minOccurs="0"/>
 *         &lt;element name="OccasionType" type="{}StringNotNull" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "battery",
    "colorMap",
    "finish",
    "isStainResistant",
    "lightSourceType",
    "material",
    "maximumCoverageArea",
    "numberOfSets",
    "outputCapacity",
    "pieceCount",
    "shape",
    "threadCount",
    "towelWeight",
    "variationData",
    "wattage",
    "innerMaterialType",
    "itemDiameter",
    "batteryCellComposition",
    "batteryFormFactor",
    "paintType",
    "customerRestrictionType",
    "occasionType"
})
@XmlRootElement(name = "Home")
public class Home {
    @XmlElement(name = "Battery")
    protected Battery battery;
    @XmlElement(name = "ColorMap")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String colorMap;
    @XmlElement(name = "Finish")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String finish;
    @XmlElement(name = "IsStainResistant")
    protected Boolean isStainResistant;
    @XmlElement(name = "LightSourceType")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String lightSourceType;
    @XmlElement(name = "Material")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String material;
    @XmlElement(name = "MaximumCoverageArea")
    protected AreaDimensionOptionalUnit maximumCoverageArea;
    @XmlElement(name = "NumberOfSets")
    protected BigInteger numberOfSets;
    @XmlElement(name = "OutputCapacity")
    protected VolumeRateDimension outputCapacity;
    @XmlElement(name = "PieceCount")
    protected BigInteger pieceCount;
    @XmlElement(name = "Shape")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String shape;
    @XmlElement(name = "ThreadCount")
    protected BigInteger threadCount;
    @XmlElement(name = "TowelWeight")
    protected WeightDimension towelWeight;
    @XmlElement(name = "VariationData")
    protected VariationData variationData;
    @XmlElement(name = "Wattage")
    protected WattageDimensionOptionalUnit wattage;
    @XmlElement(name = "InnerMaterialType")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String innerMaterialType;
    @XmlElement(name = "ItemDiameter")
    protected LengthDimension itemDiameter;
    @XmlElement(name = "BatteryCellComposition")
    protected BatteryCellTypeValues batteryCellComposition;
    @XmlElement(name = "BatteryFormFactor")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String batteryFormFactor;
    @XmlElement(name = "PaintType")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String paintType;
    @XmlElement(name = "CustomerRestrictionType")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String customerRestrictionType;
    @XmlElement(name = "OccasionType")
    @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
    protected String occasionType;

    /**
     * Gets the value of the battery property.
     * 
     * @return
     *     possible object is
     *     {@link Battery }
     *     
     */
    public Battery getBattery() {
        return battery;
    }

    /**
     * Sets the value of the battery property.
     * 
     * @param value
     *     allowed object is
     *     {@link Battery }
     *     
     */
    public void setBattery(Battery value) {
        this.battery = value;
    }

    /**
     * Gets the value of the colorMap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColorMap() {
        return colorMap;
    }

    /**
     * Sets the value of the colorMap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColorMap(String value) {
        this.colorMap = value;
    }

    /**
     * Gets the value of the finish property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinish() {
        return finish;
    }

    /**
     * Sets the value of the finish property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinish(String value) {
        this.finish = value;
    }

    /**
     * Gets the value of the isStainResistant property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsStainResistant() {
        return isStainResistant;
    }

    /**
     * Sets the value of the isStainResistant property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsStainResistant(Boolean value) {
        this.isStainResistant = value;
    }

    /**
     * Gets the value of the lightSourceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLightSourceType() {
        return lightSourceType;
    }

    /**
     * Sets the value of the lightSourceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLightSourceType(String value) {
        this.lightSourceType = value;
    }

    /**
     * Gets the value of the material property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaterial() {
        return material;
    }

    /**
     * Sets the value of the material property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaterial(String value) {
        this.material = value;
    }

    /**
     * Gets the value of the maximumCoverageArea property.
     * 
     * @return
     *     possible object is
     *     {@link AreaDimensionOptionalUnit }
     *     
     */
    public AreaDimensionOptionalUnit getMaximumCoverageArea() {
        return maximumCoverageArea;
    }

    /**
     * Sets the value of the maximumCoverageArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link AreaDimensionOptionalUnit }
     *     
     */
    public void setMaximumCoverageArea(AreaDimensionOptionalUnit value) {
        this.maximumCoverageArea = value;
    }

    /**
     * Gets the value of the numberOfSets property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumberOfSets() {
        return numberOfSets;
    }

    /**
     * Sets the value of the numberOfSets property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumberOfSets(BigInteger value) {
        this.numberOfSets = value;
    }

    /**
     * Gets the value of the outputCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link VolumeRateDimension }
     *     
     */
    public VolumeRateDimension getOutputCapacity() {
        return outputCapacity;
    }

    /**
     * Sets the value of the outputCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link VolumeRateDimension }
     *     
     */
    public void setOutputCapacity(VolumeRateDimension value) {
        this.outputCapacity = value;
    }

    /**
     * Gets the value of the pieceCount property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPieceCount() {
        return pieceCount;
    }

    /**
     * Sets the value of the pieceCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPieceCount(BigInteger value) {
        this.pieceCount = value;
    }

    /**
     * Gets the value of the shape property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShape() {
        return shape;
    }

    /**
     * Sets the value of the shape property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShape(String value) {
        this.shape = value;
    }

    /**
     * Gets the value of the threadCount property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getThreadCount() {
        return threadCount;
    }

    /**
     * Sets the value of the threadCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setThreadCount(BigInteger value) {
        this.threadCount = value;
    }

    /**
     * Gets the value of the towelWeight property.
     * 
     * @return
     *     possible object is
     *     {@link WeightDimension }
     *     
     */
    public WeightDimension getTowelWeight() {
        return towelWeight;
    }

    /**
     * Sets the value of the towelWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link WeightDimension }
     *     
     */
    public void setTowelWeight(WeightDimension value) {
        this.towelWeight = value;
    }

    /**
     * Gets the value of the variationData property.
     * 
     * @return
     *     possible object is
     *     {@link Home.ProductType.Home.VariationData }
     *     
     */
    public VariationData getVariationData() {
        return variationData;
    }

    /**
     * Sets the value of the variationData property.
     * 
     * @param value
     *     allowed object is
     *     {@link Home.ProductType.Home.VariationData }
     *     
     */
    public void setVariationData(VariationData value) {
        this.variationData = value;
    }

    /**
     * Gets the value of the wattage property.
     * 
     * @return
     *     possible object is
     *     {@link WattageDimensionOptionalUnit }
     *     
     */
    public WattageDimensionOptionalUnit getWattage() {
        return wattage;
    }

    /**
     * Sets the value of the wattage property.
     * 
     * @param value
     *     allowed object is
     *     {@link WattageDimensionOptionalUnit }
     *     
     */
    public void setWattage(WattageDimensionOptionalUnit value) {
        this.wattage = value;
    }

    /**
     * Gets the value of the innerMaterialType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInnerMaterialType() {
        return innerMaterialType;
    }

    /**
     * Sets the value of the innerMaterialType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInnerMaterialType(String value) {
        this.innerMaterialType = value;
    }

    /**
     * Gets the value of the itemDiameter property.
     * 
     * @return
     *     possible object is
     *     {@link LengthDimension }
     *     
     */
    public LengthDimension getItemDiameter() {
        return itemDiameter;
    }

    /**
     * Sets the value of the itemDiameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link LengthDimension }
     *     
     */
    public void setItemDiameter(LengthDimension value) {
        this.itemDiameter = value;
    }

    /**
     * Gets the value of the batteryCellComposition property.
     * 
     * @return
     *     possible object is
     *     {@link BatteryCellTypeValues }
     *     
     */
    public BatteryCellTypeValues getBatteryCellComposition() {
        return batteryCellComposition;
    }

    /**
     * Sets the value of the batteryCellComposition property.
     * 
     * @param value
     *     allowed object is
     *     {@link BatteryCellTypeValues }
     *     
     */
    public void setBatteryCellComposition(BatteryCellTypeValues value) {
        this.batteryCellComposition = value;
    }

    /**
     * Gets the value of the batteryFormFactor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryFormFactor() {
        return batteryFormFactor;
    }

    /**
     * Sets the value of the batteryFormFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryFormFactor(String value) {
        this.batteryFormFactor = value;
    }

    /**
     * Gets the value of the paintType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaintType() {
        return paintType;
    }

    /**
     * Sets the value of the paintType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaintType(String value) {
        this.paintType = value;
    }

    /**
     * Gets the value of the customerRestrictionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerRestrictionType() {
        return customerRestrictionType;
    }

    /**
     * Sets the value of the customerRestrictionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerRestrictionType(String value) {
        this.customerRestrictionType = value;
    }

    /**
     * Gets the value of the occasionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOccasionType() {
        return occasionType;
    }

    /**
     * Sets the value of the occasionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOccasionType(String value) {
        this.occasionType = value;
    }
    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Parentage" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;enumeration value="parent"/>
     *               &lt;enumeration value="child"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="VariationTheme" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;enumeration value="Size"/>
     *               &lt;enumeration value="Color"/>
     *               &lt;enumeration value="Length-Width"/>
     *               &lt;enumeration value="Length-Material"/>
     *               &lt;enumeration value="Length-Size"/>
     *               &lt;enumeration value="Length-Color"/>
     *               &lt;enumeration value="Length-Height"/>
     *               &lt;enumeration value="Width-Material"/>
     *               &lt;enumeration value="Width-Size"/>
     *               &lt;enumeration value="Width-Color"/>
     *               &lt;enumeration value="Width-Height"/>
     *               &lt;enumeration value="NumberOfItemsInPackage-Material"/>
     *               &lt;enumeration value="NumberOfItemsInPackage-Size"/>
     *               &lt;enumeration value="NumberOfItemsInPackage-Color"/>
     *               &lt;enumeration value="NumberOfItemsInPackage-Height"/>
     *               &lt;enumeration value="Weight-NumberOfItemsInPackage"/>
     *               &lt;enumeration value="Weight-Material"/>
     *               &lt;enumeration value="Weight-Size"/>
     *               &lt;enumeration value="Weight-Color"/>
     *               &lt;enumeration value="Weight-Height"/>
     *               &lt;enumeration value="Material-Length"/>
     *               &lt;enumeration value="Material-Width"/>
     *               &lt;enumeration value="Material-Size"/>
     *               &lt;enumeration value="Material-Color"/>
     *               &lt;enumeration value="Material-Height"/>
     *               &lt;enumeration value="Size-Length"/>
     *               &lt;enumeration value="Size-Width"/>
     *               &lt;enumeration value="Size-Weight"/>
     *               &lt;enumeration value="Size-Material"/>
     *               &lt;enumeration value="Size-Color"/>
     *               &lt;enumeration value="Size-Height"/>
     *               &lt;enumeration value="Color-Length"/>
     *               &lt;enumeration value="Color-Width"/>
     *               &lt;enumeration value="Color-NumberOfItemsInPackage"/>
     *               &lt;enumeration value="Color-Weight"/>
     *               &lt;enumeration value="Color-Material"/>
     *               &lt;enumeration value="Color-Size"/>
     *               &lt;enumeration value="Color-Height"/>
     *               &lt;enumeration value="Height"/>
     *               &lt;enumeration value="Material"/>
     *               &lt;enumeration value="Weight"/>
     *               &lt;enumeration value="Length"/>
     *               &lt;enumeration value="NumberOfItemsInPackage"/>
     *               &lt;enumeration value="Length-PatternName"/>
     *               &lt;enumeration value="Length-StyleName"/>
     *               &lt;enumeration value="Width-PatternName"/>
     *               &lt;enumeration value="Width-StyleName"/>
     *               &lt;enumeration value="Occasion-PatternName"/>
     *               &lt;enumeration value="Occasion-NumberOfItemsInPackage"/>
     *               &lt;enumeration value="Occasion-Material"/>
     *               &lt;enumeration value="Occasion-StyleName"/>
     *               &lt;enumeration value="Occasion-Size"/>
     *               &lt;enumeration value="Occasion-Color"/>
     *               &lt;enumeration value="Occasion-Height"/>
     *               &lt;enumeration value="PatternName-Length"/>
     *               &lt;enumeration value="PatternName-Width"/>
     *               &lt;enumeration value="PatternName-Occasion"/>
     *               &lt;enumeration value="PatternName-Material"/>
     *               &lt;enumeration value="PatternName-StyleName"/>
     *               &lt;enumeration value="PatternName-Size"/>
     *               &lt;enumeration value="PatternName-Color"/>
     *               &lt;enumeration value="PatternName-Height"/>
     *               &lt;enumeration value="MatteStyle-Material"/>
     *               &lt;enumeration value="MatteStyle-StyleName"/>
     *               &lt;enumeration value="MatteStyle-Size"/>
     *               &lt;enumeration value="MatteStyle-Color"/>
     *               &lt;enumeration value="NumberOfItemsInPackage-Occasion"/>
     *               &lt;enumeration value="NumberOfItemsInPackage-StyleName"/>
     *               &lt;enumeration value="Weight-StyleName"/>
     *               &lt;enumeration value="Material-PatternName"/>
     *               &lt;enumeration value="Material-MatteStyle"/>
     *               &lt;enumeration value="Material-StyleName"/>
     *               &lt;enumeration value="StyleName-Length"/>
     *               &lt;enumeration value="StyleName-Width"/>
     *               &lt;enumeration value="StyleName-Occasion"/>
     *               &lt;enumeration value="StyleName-PatternName"/>
     *               &lt;enumeration value="StyleName-Weight"/>
     *               &lt;enumeration value="StyleName-Material"/>
     *               &lt;enumeration value="StyleName-Size"/>
     *               &lt;enumeration value="StyleName-Color"/>
     *               &lt;enumeration value="Size-Occasion"/>
     *               &lt;enumeration value="Size-PatternName"/>
     *               &lt;enumeration value="Size-MatteStyle"/>
     *               &lt;enumeration value="Size-StyleName"/>
     *               &lt;enumeration value="Color-Occasion"/>
     *               &lt;enumeration value="Color-PatternName"/>
     *               &lt;enumeration value="Color-MatteStyle"/>
     *               &lt;enumeration value="Color-StyleName"/>
     *               &lt;enumeration value="MatteStyle"/>
     *               &lt;enumeration value="PatternName"/>
     *               &lt;enumeration value="Occasion"/>
     *               &lt;enumeration value="StyleName"/>
     *               &lt;enumeration value="Weight-Length-Color"/>
     *               &lt;enumeration value="Occasion-Size-Color"/>
     *               &lt;enumeration value="Weight-Length-Material"/>
     *               &lt;enumeration value="Weight-Length-StyleName"/>
     *               &lt;enumeration value="PatternName-Size-Occasion"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="Size" type="{}StringNotNull" minOccurs="0"/>
     *         &lt;element name="Color" type="{}StringNotNull" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
     
    })
    public static class VariationData {
        @XmlElement(name = "VariationTheme")
        protected String variationTheme;
        @XmlElement(name = "Size")
        @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
        protected String size;
        @XmlElement(name = "Color")
        @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
        protected String color;
        @XmlElement(name = "Scent")
        @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
        protected String scent;
        @XmlElement(name = "CustomerPackageType")
        @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
        protected String customerPackageType;


        /**
         * Gets the value of the variationTheme property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getVariationTheme() {
            return variationTheme;
        }

        /**
         * Sets the value of the variationTheme property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setVariationTheme(String value) {
            this.variationTheme = value;
        }

        /**
         * Gets the value of the size property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSize() {
            return size;
        }

        /**
         * Sets the value of the size property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSize(String value) {
            this.size = value;
        }

        /**
         * Gets the value of the color property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getColor() {
            return color;
        }

        /**
         * Sets the value of the color property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setColor(String value) {
            this.color = value;
        }
    }
}
