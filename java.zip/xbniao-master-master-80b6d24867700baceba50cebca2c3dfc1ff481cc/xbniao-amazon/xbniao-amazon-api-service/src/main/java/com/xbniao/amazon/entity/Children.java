package com.xbniao.amazon.entity;

public class Children {
	private String refinementName;
	private String refinementvalue;
	private int hasModifier;
	private String modifiers;
	private String refinementAttribute;
	private String fieldName;
	public String getRefinementName() {
		return refinementName;
	}
	public void setRefinementName(String refinementName) {
		this.refinementName = refinementName;
	}
	public String getRefinementvalue() {
		return refinementvalue;
	}
	public void setRefinementvalue(String refinementvalue) {
		this.refinementvalue = refinementvalue;
	}
	public int getHasModifier() {
		return hasModifier;
	}
	public void setHasModifier(int hasModifier) {
		this.hasModifier = hasModifier;
	}
	public String getModifiers() {
		return modifiers;
	}
	public void setModifiers(String modifiers) {
		this.modifiers = modifiers;
	}
	public String getRefinementAttribute() {
		return refinementAttribute;
	}
	public void setRefinementAttribute(String refinementAttribute) {
		this.refinementAttribute = refinementAttribute;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	
}
